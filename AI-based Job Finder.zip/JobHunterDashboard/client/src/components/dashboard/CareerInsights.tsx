import { TopSkill, CareerEvent } from "../../types";
import { Button } from "@/components/ui/button";

interface CareerInsightsProps {
  topSkills: TopSkill[];
  events: CareerEvent[];
}

const CareerInsights = ({ topSkills, events }: CareerInsightsProps) => {
  const formatEventDate = (date: string) => {
    const eventDate = new Date(date);
    return {
      day: eventDate.getDate(),
      month: eventDate.toLocaleString('default', { month: 'short' }).toUpperCase()
    };
  };

  return (
    <div>
      <h2 className="text-lg font-medium mb-4">Career Insights</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-surface-dark rounded-lg shadow-card dark:shadow-card-dark p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium">Top Skills in Demand</h3>
            <Button variant="link" size="sm" className="text-primary dark:text-primary-light hover:underline">
              View All
            </Button>
          </div>
          
          <div className="space-y-4">
            {topSkills.map((skill, i) => (
              <div key={i}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm">{skill.name}</span>
                  <span className="text-xs text-text-light-secondary dark:text-text-dark-secondary">
                    {skill.percentage}% of jobs
                  </span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-blue-500 h-2 rounded-full" 
                    style={{ width: `${skill.percentage}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-white dark:bg-surface-dark rounded-lg shadow-card dark:shadow-card-dark p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium">Career Events</h3>
            <Button variant="link" size="sm" className="text-primary dark:text-primary-light hover:underline">
              View All
            </Button>
          </div>
          
          <div className="space-y-4">
            {events.map((event, i) => {
              const { day, month } = formatEventDate(event.date);
              return (
                <div key={i} className="flex items-start">
                  <div className="bg-indigo-100 dark:bg-indigo-900/30 text-center p-2 rounded-lg mr-3">
                    <div className="text-indigo-800 dark:text-indigo-300 font-medium">{day}</div>
                    <div className="text-xs text-indigo-600 dark:text-indigo-400">{month}</div>
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">{event.title}</h4>
                    <p className="text-xs text-text-light-secondary dark:text-text-dark-secondary mt-1">
                      {event.isVirtual ? 'Virtual Event' : event.location} • {event.time}
                    </p>
                    <div className="mt-2">
                      <Button 
                        variant="link" 
                        size="sm" 
                        className="text-primary dark:text-primary-light text-xs px-0 hover:underline"
                      >
                        Add to Calendar
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
            
            <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 mt-4 flex items-center">
              <div className="mr-4">
                <img 
                  src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100&q=80" 
                  alt="Headshot of professional looking man" 
                  className="w-14 h-14 rounded-full object-cover" 
                />
              </div>
              <div>
                <h4 className="font-medium text-sm">Interview Prep Coaching</h4>
                <p className="text-xs text-text-light-secondary dark:text-text-dark-secondary mt-1">
                  Get 1-on-1 coaching for your next interview
                </p>
                <Button size="sm" className="mt-2">
                  Book Session
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CareerInsights;
