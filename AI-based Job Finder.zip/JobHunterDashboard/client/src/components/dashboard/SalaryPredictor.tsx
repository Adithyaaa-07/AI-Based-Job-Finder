import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { DollarSign, TrendingUp, MapPin, Briefcase } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";

interface SalaryPrediction {
  minSalary: number;
  maxSalary: number;
  averageSalary: number;
  marketTrend: "up" | "down" | "stable";
  trendPercentage: number;
  confidence: number;
  demandLevel: "high" | "medium" | "low";
}

const ExperienceLevels = ["Entry-level", "Mid-level", "Senior", "Lead", "Executive"];
const JobTypes = ["Full-time", "Part-time", "Contract", "Freelance"];
const LocationTypes = ["Remote", "On-site", "Hybrid"];

const SalaryPredictor = () => {
  const { toast } = useToast();
  const [jobTitle, setJobTitle] = useState("");
  const [location, setLocation] = useState("");
  const [skills, setSkills] = useState("");
  const [experienceYears, setExperienceYears] = useState(3);
  const [experienceLevel, setExperienceLevel] = useState("Mid-level");
  const [jobType, setJobType] = useState("Full-time");
  const [locationType, setLocationType] = useState("Hybrid");
  const [isFormValid, setIsFormValid] = useState(false);
  const [showResults, setShowResults] = useState(false);
  
  // Simulated prediction - this would be replaced with a real API call
  const [prediction, setPrediction] = useState<SalaryPrediction>({
    minSalary: 85000,
    maxSalary: 115000,
    averageSalary: 98000,
    marketTrend: "up",
    trendPercentage: 5.3,
    confidence: 85,
    demandLevel: "high"
  });

  // Check form validity
  const validateForm = () => {
    const valid = 
      jobTitle.trim() !== "" && 
      location.trim() !== "" && 
      skills.trim() !== "";
    setIsFormValid(valid);
    return valid;
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast({
        title: "Missing Information",
        description: "Please fill out all required fields",
        variant: "destructive"
      });
      return;
    }

    // This would be an API call to get salary prediction
    // For now, we'll use simulated data with minor randomization
    
    const baseMin = 75000 + (experienceYears * 5000);
    const baseMax = baseMin + 30000;
    const randomFactor = Math.random() * 10000 - 5000;
    
    // Adjust based on experience level
    const levelMultiplier = {
      "Entry-level": 0.7,
      "Mid-level": 1.0,
      "Senior": 1.4,
      "Lead": 1.7,
      "Executive": 2.2
    }[experienceLevel] || 1.0;
    
    // Adjust based on job type
    const typeMultiplier = {
      "Full-time": 1.0,
      "Part-time": 0.6,
      "Contract": 1.2,
      "Freelance": 1.1
    }[jobType] || 1.0;
    
    const newPrediction: SalaryPrediction = {
      minSalary: Math.round((baseMin + randomFactor) * levelMultiplier * typeMultiplier),
      maxSalary: Math.round((baseMax + randomFactor) * levelMultiplier * typeMultiplier),
      averageSalary: 0, // Will be calculated below
      marketTrend: Math.random() > 0.3 ? "up" : Math.random() > 0.5 ? "stable" : "down",
      trendPercentage: +(Math.random() * 7 + 1).toFixed(1),
      confidence: Math.round(Math.random() * 15 + 80),
      demandLevel: Math.random() > 0.6 ? "high" : Math.random() > 0.5 ? "medium" : "low"
    };
    
    // Calculate average
    newPrediction.averageSalary = Math.round((newPrediction.minSalary + newPrediction.maxSalary) / 2);
    
    setPrediction(newPrediction);
    setShowResults(true);
    
    toast({
      title: "Salary Prediction Ready",
      description: "Based on market data analysis"
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="flex flex-col">
      <form onSubmit={handleSubmit} className="mb-6" onChange={validateForm}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="space-y-2">
            <Label htmlFor="jobTitle">Job Title</Label>
            <Input
              id="jobTitle"
              value={jobTitle}
              onChange={(e) => setJobTitle(e.target.value)}
              placeholder="e.g. Software Engineer"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. San Francisco, CA"
              required
            />
          </div>
        </div>
        
        <div className="mb-4">
          <Label htmlFor="skills">Key Skills (comma separated)</Label>
          <Input
            id="skills"
            value={skills}
            onChange={(e) => setSkills(e.target.value)}
            placeholder="e.g. React, TypeScript, Node.js"
            required
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div className="space-y-2">
            <Label>Experience Level</Label>
            <Select 
              value={experienceLevel} 
              onValueChange={setExperienceLevel}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select level" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Experience Level</SelectLabel>
                  {ExperienceLevels.map(level => (
                    <SelectItem key={level} value={level}>{level}</SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label>Job Type</Label>
            <Select 
              value={jobType} 
              onValueChange={setJobType}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Job Type</SelectLabel>
                  {JobTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label>Location Type</Label>
            <Select 
              value={locationType} 
              onValueChange={setLocationType}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Location Type</SelectLabel>
                  {LocationTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between mb-2">
            <Label>Years of Experience: {experienceYears}</Label>
          </div>
          <Slider
            value={[experienceYears]}
            min={0}
            max={15}
            step={1}
            onValueChange={(values) => setExperienceYears(values[0])}
            className="mt-2"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>Entry Level</span>
            <span>Mid Career</span>
            <span>Senior Level</span>
          </div>
        </div>
        
        <Button type="submit" className="w-full" disabled={!isFormValid}>
          Predict Salary Range
        </Button>
      </form>
      
      {showResults && (
        <div className="space-y-4">
          <div className="bg-primary/5 dark:bg-primary/10 p-4 rounded-lg border border-primary/20">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg font-semibold flex items-center">
                <DollarSign className="h-5 w-5 mr-1 text-green-500" />
                Predicted Salary Range
              </h3>
              <div className="text-xs px-2 py-1 bg-gray-100 dark:bg-gray-800 rounded-full">
                {prediction.confidence}% confidence
              </div>
            </div>
            
            <div className="text-3xl font-bold text-center my-4">
              {formatCurrency(prediction.minSalary)} - {formatCurrency(prediction.maxSalary)}
              <div className="text-sm font-normal text-gray-500 dark:text-gray-400 mt-1">
                Average: {formatCurrency(prediction.averageSalary)}
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
              <Card>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium">Market Trend</div>
                    <div className={`flex items-center ${
                      prediction.marketTrend === "up" 
                        ? "text-green-500" 
                        : prediction.marketTrend === "down" 
                        ? "text-red-500" 
                        : "text-yellow-500"
                    }`}>
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span>{prediction.trendPercentage}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium">Location Impact</div>
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1 text-blue-500" />
                      <span>+8%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium">Market Demand</div>
                    <div className={`flex items-center ${
                      prediction.demandLevel === "high" 
                        ? "text-green-500" 
                        : prediction.demandLevel === "medium" 
                        ? "text-yellow-500" 
                        : "text-red-500"
                    }`}>
                      <Briefcase className="h-4 w-4 mr-1" />
                      <span className="capitalize">{prediction.demandLevel}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
          
          <div className="mt-4">
            <h4 className="text-sm font-medium mb-2">Salary Comparison</h4>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Industry Average</span>
                  <span>{formatCurrency(prediction.averageSalary - 5000)}</span>
                </div>
                <Progress value={80} className="h-2" />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Your Predicted Salary</span>
                  <span>{formatCurrency(prediction.averageSalary)}</span>
                </div>
                <Progress value={100} className="h-2" />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Top 10% Earners</span>
                  <span>{formatCurrency(prediction.maxSalary + 15000)}</span>
                </div>
                <Progress value={50} className="h-2" />
              </div>
            </div>
          </div>
          
          <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
            <p>This prediction is based on current market data, job postings, and industry trends. Actual salaries may vary based on company size, industry, and specific requirements.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default SalaryPredictor;