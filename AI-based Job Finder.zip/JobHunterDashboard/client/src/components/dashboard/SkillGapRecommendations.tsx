import { Recommendation } from "../../types";
import { Lightbulb } from "lucide-react";

interface SkillGapRecommendationsProps {
  recommendations: Recommendation[];
  insightText: string;
}

const SkillGapRecommendations = ({ recommendations, insightText }: SkillGapRecommendationsProps) => {
  const getRecommendationBadge = (impactLevel: string) => {
    switch(impactLevel) {
      case 'High':
        return (
          <span className="text-xs bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400 py-1 px-2 rounded-full">
            High Impact
          </span>
        );
      case 'Medium':
        return (
          <span className="text-xs bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-400 py-1 px-2 rounded-full">
            Medium Impact
          </span>
        );
      case 'Long-term':
        return (
          <span className="text-xs bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400 py-1 px-2 rounded-full">
            Long-term
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="col-span-1 lg:col-span-2">
      <h3 className="font-medium mb-3">Skill Gap Recommendations</h3>
      
      <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg mb-4">
        <div className="flex items-start">
          <Lightbulb className="text-blue-600 dark:text-blue-400 mr-2 h-5 w-5" />
          <div>
            <h4 className="font-medium text-blue-800 dark:text-blue-300">AI Insights</h4>
            <p className="text-sm text-blue-600 dark:text-blue-400 mt-1">
              {insightText}
            </p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {recommendations.map((recommendation, index) => (
          <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg p-3">
            <div className="flex justify-between">
              <h4 className="font-medium">{recommendation.title}</h4>
              {getRecommendationBadge(recommendation.impactLevel)}
            </div>
            <p className="text-sm text-text-light-secondary dark:text-text-dark-secondary mt-2">
              {recommendation.description}
            </p>
            <button className="mt-3 text-sm text-primary dark:text-primary-light hover:underline focus:outline-none">
              View Courses
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SkillGapRecommendations;
