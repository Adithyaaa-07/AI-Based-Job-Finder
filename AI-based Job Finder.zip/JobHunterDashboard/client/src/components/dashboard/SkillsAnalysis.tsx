import { Skill } from "../../types";

interface SkillsAnalysisProps {
  skills: Skill[];
  overallMatch: number;
}

const SkillsAnalysis = ({ skills, overallMatch }: SkillsAnalysisProps) => {
  const getSkillLevelColor = (level: number) => {
    if (level >= 80) return "bg-green-500";
    if (level >= 60) return "bg-yellow-500";
    return "bg-red-500";
  };

  return (
    <div className="col-span-1">
      <img 
        src="https://images.unsplash.com/photo-1497366811353-6870744d04b2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80" 
        alt="Office workspace" 
        className="w-full h-48 object-cover rounded-lg" 
      />
      <h3 className="mt-4 font-medium">Skills Analysis</h3>
      <p className="text-sm text-text-light-secondary dark:text-text-dark-secondary mt-1">
        Your skills match {overallMatch}% of current job market demand
      </p>
      
      <div className="mt-4">
        {skills.map((skill, index) => (
          <div key={index}>
            <div className="flex justify-between text-sm">
              <span>{skill.name}</span>
              <span>{skill.level}%</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full">
              <div 
                className={`skill-bar ${getSkillLevelColor(skill.level)} rounded-full`} 
                style={{ width: `${skill.level}%` }}
              ></div>
            </div>
            {index < skills.length - 1 && <div className="mt-2"></div>}
          </div>
        ))}
      </div>
    </div>
  );
};

export default SkillsAnalysis;
