import { useState } from "react";
import { JobFilters as JobFiltersType } from "../../types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Filter, ChevronDown, MapPin, Plus } from "lucide-react";

interface JobFiltersProps {
  filters: JobFiltersType;
  onApplyFilters: (filters: JobFiltersType) => void;
  onClearFilters: () => void;
  isVisible: boolean;
  toggleVisibility: () => void;
}

const JobFilters = ({ 
  filters, 
  onApplyFilters, 
  onClearFilters, 
  isVisible,
  toggleVisibility
}: JobFiltersProps) => {
  const [localFilters, setLocalFilters] = useState<JobFiltersType>(filters);
  
  const handleJobTypeChange = (checked: boolean | "indeterminate", type: string) => {
    if (checked === "indeterminate") return;
    
    const jobTypes = localFilters.jobType || [];
    let newJobTypes;
    
    if (checked) {
      newJobTypes = [...jobTypes, type as any];
    } else {
      newJobTypes = jobTypes.filter(t => t !== type);
    }
    
    setLocalFilters({ ...localFilters, jobType: newJobTypes });
  };
  
  const handleLocationChange = (value: string) => {
    setLocalFilters({ ...localFilters, location: value });
  };
  
  const handleExperienceLevelChange = (value: string) => {
    setLocalFilters({ ...localFilters, experienceLevel: value ? [value as any] : undefined });
  };
  
  const handleSalaryRangeChange = (value: string) => {
    switch (value) {
      case "40k-60k":
        setLocalFilters({ ...localFilters, salaryMin: 40000, salaryMax: 60000 });
        break;
      case "60k-80k":
        setLocalFilters({ ...localFilters, salaryMin: 60000, salaryMax: 80000 });
        break;
      case "80k-100k":
        setLocalFilters({ ...localFilters, salaryMin: 80000, salaryMax: 100000 });
        break;
      case "100k+":
        setLocalFilters({ ...localFilters, salaryMin: 100000, salaryMax: undefined });
        break;
      default:
        setLocalFilters({ ...localFilters, salaryMin: undefined, salaryMax: undefined });
    }
  };
  
  const handlePostedDateChange = (value: string) => {
    setLocalFilters({ ...localFilters, postedWithin: value as any });
  };
  
  const handleApplyFilters = () => {
    onApplyFilters(localFilters);
  };
  
  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
        <h2 className="text-lg font-medium">Recommended Jobs</h2>
        
        <div className="flex items-center space-x-2 mt-2 md:mt-0">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex items-center text-sm"
            onClick={toggleVisibility}
          >
            <Filter className="h-4 w-4 mr-1" />
            Filter
          </Button>
          
          <div className="relative">
            <Select defaultValue="relevance">
              <SelectTrigger className="w-[160px] h-9 text-sm">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="relevance">Sort: Relevance</SelectItem>
                <SelectItem value="date">Sort: Date</SelectItem>
                <SelectItem value="salary">Sort: Salary</SelectItem>
                <SelectItem value="company">Sort: Company</SelectItem>
              </SelectContent>
            </Select>
            <ChevronDown className="absolute right-3 top-2.5 h-4 w-4 pointer-events-none text-gray-500 dark:text-gray-400" />
          </div>
        </div>
      </div>
      
      {isVisible && (
        <div className="mb-4 p-4 bg-white dark:bg-surface-dark rounded-lg shadow-card dark:shadow-card-dark">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label className="block text-sm font-medium mb-1">Location</Label>
              <div className="relative">
                <Input 
                  type="text" 
                  placeholder="Any location" 
                  value={localFilters.location || ""}
                  onChange={(e) => handleLocationChange(e.target.value)}
                  className="w-full pr-8"
                />
                <MapPin className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
              </div>
            </div>
            
            <div>
              <Label className="block text-sm font-medium mb-1">Job Type</Label>
              <div className="flex flex-wrap gap-2">
                <Label className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-700 rounded-md text-sm bg-white dark:bg-gray-800 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                  <Checkbox 
                    className="h-4 w-4 mr-2" 
                    checked={localFilters.jobType?.includes('Full-time')}
                    onCheckedChange={(checked) => handleJobTypeChange(checked, "Full-time")}
                  />
                  Full-time
                </Label>
                <Label className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-700 rounded-md text-sm bg-white dark:bg-gray-800 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                  <Checkbox 
                    className="h-4 w-4 mr-2" 
                    checked={localFilters.jobType?.includes('Part-time')}
                    onCheckedChange={(checked) => handleJobTypeChange(checked, "Part-time")}
                  />
                  Part-time
                </Label>
                <Label className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-700 rounded-md text-sm bg-white dark:bg-gray-800 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                  <Checkbox 
                    className="h-4 w-4 mr-2" 
                    checked={localFilters.jobType?.includes('Contract')}
                    onCheckedChange={(checked) => handleJobTypeChange(checked, "Contract")}
                  />
                  Contract
                </Label>
              </div>
            </div>
            
            <div>
              <Label className="block text-sm font-medium mb-1">Experience Level</Label>
              <Select 
                value={localFilters.experienceLevel?.[0] || ""}
                onValueChange={handleExperienceLevelChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All levels" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All levels</SelectItem>
                  <SelectItem value="Entry">Entry level</SelectItem>
                  <SelectItem value="Mid">Mid-Senior level</SelectItem>
                  <SelectItem value="Senior">Senior level</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="block text-sm font-medium mb-1">Salary Range</Label>
              <Select
                value={
                  localFilters.salaryMin === 40000 && localFilters.salaryMax === 60000 ? "40k-60k" :
                  localFilters.salaryMin === 60000 && localFilters.salaryMax === 80000 ? "60k-80k" :
                  localFilters.salaryMin === 80000 && localFilters.salaryMax === 100000 ? "80k-100k" :
                  localFilters.salaryMin === 100000 ? "100k+" : ""
                }
                onValueChange={handleSalaryRangeChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Any salary" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Any salary</SelectItem>
                  <SelectItem value="40k-60k">$40k - $60k</SelectItem>
                  <SelectItem value="60k-80k">$60k - $80k</SelectItem>
                  <SelectItem value="80k-100k">$80k - $100k</SelectItem>
                  <SelectItem value="100k+">$100k+</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="block text-sm font-medium mb-1">Posted Date</Label>
              <Select
                value={localFilters.postedWithin || "all"}
                onValueChange={handlePostedDateChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Any time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any time</SelectItem>
                  <SelectItem value="day">Past 24 hours</SelectItem>
                  <SelectItem value="week">Past week</SelectItem>
                  <SelectItem value="month">Past month</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="block text-sm font-medium mb-1">Skills</Label>
              <div className="relative">
                <Input type="text" placeholder="Add skills" className="w-full pr-8" />
                <Plus className="absolute right-3 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
              </div>
            </div>
          </div>
          
          <div className="flex justify-between mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onClearFilters}
              className="text-gray-600 dark:text-gray-400 hover:underline"
            >
              Clear all filters
            </Button>
            <Button onClick={handleApplyFilters}>
              Apply Filters
            </Button>
          </div>
        </div>
      )}
    </>
  );
};

export default JobFilters;
