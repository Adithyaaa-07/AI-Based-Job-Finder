import { useState } from "react";
import { Job } from "../../types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bookmark, BookmarkCheck, Briefcase, Clock, DollarSign, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

interface JobCardProps {
  job: Job;
  isSaved?: boolean;
  onViewJob?: (job: Job) => void;
}

const JobCard = ({ job, isSaved = false, onViewJob }: JobCardProps) => {
  const [saved, setSaved] = useState(isSaved);
  const { toast } = useToast();
  
  const formatSalary = (min?: number, max?: number) => {
    if (!min && !max) return "Competitive salary";
    if (min && !max) return `$${(min / 1000).toFixed(0)}k+`;
    if (!min && max) return `Up to $${(max / 1000).toFixed(0)}k`;
    return `$${(min! / 1000).toFixed(0)}k - $${(max! / 1000).toFixed(0)}k`;
  };
  
  const getPostedTimeAgo = (postedDate: string) => {
    const posted = new Date(postedDate);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - posted.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return "Posted today";
    if (diffDays === 1) return "Posted yesterday";
    if (diffDays < 7) return `Posted ${diffDays} days ago`;
    if (diffDays < 30) return `Posted ${Math.floor(diffDays / 7)} week${Math.floor(diffDays / 7) > 1 ? 's' : ''} ago`;
    return `Posted ${Math.floor(diffDays / 30)} month${Math.floor(diffDays / 30) > 1 ? 's' : ''} ago`;
  };
  
  const getMatchBadgeColor = (matchPercentage?: number) => {
    if (!matchPercentage) return "";
    
    if (matchPercentage >= 85) {
      return "bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400";
    } else if (matchPercentage >= 70) {
      return "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400";
    } else {
      return "bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-400";
    }
  };
  
  const getCompanyIconColor = () => {
    const colors = [
      "bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400",
      "bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400",
      "bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400", 
      "bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400",
      "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-600 dark:text-yellow-400",
      "bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400"
    ];
    
    // Use the company name to deterministically select a color
    const index = job.company.charCodeAt(0) % colors.length;
    return colors[index];
  };
  
  const toggleSaveJob = async () => {
    try {
      if (saved) {
        await apiRequest('DELETE', `/api/jobs/${job.id}/save`);
        setSaved(false);
        toast({
          description: "Job removed from saved jobs",
        });
      } else {
        await apiRequest('POST', `/api/jobs/${job.id}/save`);
        setSaved(true);
        toast({
          description: "Job saved successfully",
        });
      }
      
      // Invalidate saved jobs query
      queryClient.invalidateQueries({ queryKey: ['/api/saved-jobs'] });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "There was a problem saving this job",
      });
    }
  };
  
  return (
    <div className="job-card bg-white dark:bg-surface-dark rounded-lg shadow-card dark:shadow-card-dark hover:shadow-card-hover dark:hover:shadow-card-hover-dark overflow-hidden">
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-start">
            <div className={cn("rounded p-2 mr-3", getCompanyIconColor())}>
              <Briefcase className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-medium">{job.title}</h3>
              <p className="text-sm text-text-light-secondary dark:text-text-dark-secondary">{job.company}</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={toggleSaveJob}
            className={cn(
              "text-gray-400 hover:text-yellow-500 focus:outline-none", 
              saved && "text-yellow-500"
            )}
          >
            {saved ? <BookmarkCheck className="h-5 w-5" /> : <Bookmark className="h-5 w-5" />}
          </Button>
        </div>
        
        <div className="mt-4">
          <div className="flex items-center text-sm text-text-light-secondary dark:text-text-dark-secondary mb-2">
            <MapPin className="h-4 w-4 mr-1" />
            {job.location} ({job.locationType})
          </div>
          <div className="flex items-center text-sm text-text-light-secondary dark:text-text-dark-secondary mb-2">
            <Briefcase className="h-4 w-4 mr-1" />
            {job.jobType}
          </div>
          <div className="flex items-center text-sm text-text-light-secondary dark:text-text-dark-secondary">
            <DollarSign className="h-4 w-4 mr-1" />
            {formatSalary(job.salaryMin, job.salaryMax)}
          </div>
        </div>
        
        <div className="mt-4">
          <div className="flex flex-wrap gap-1">
            {job.skills.slice(0, 3).map((skill, i) => (
              <Badge 
                key={i}
                variant="secondary"
                className="text-xs bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 font-normal"
              >
                {skill}
              </Badge>
            ))}
            {job.skills.length > 3 && (
              <Badge 
                variant="outline"
                className="text-xs bg-primary/10 dark:bg-primary/20 text-primary dark:text-primary-light font-normal"
              >
                +{job.skills.length - 3} matches
              </Badge>
            )}
          </div>
        </div>
        
        <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
          <div className="flex items-center">
            {job.matchPercentage && (
              <span className={cn(
                "mr-2 px-2 py-1 text-xs rounded-full",
                getMatchBadgeColor(job.matchPercentage)
              )}>
                {job.matchPercentage}% match
              </span>
            )}
            <span className="text-xs text-text-light-secondary dark:text-text-dark-secondary flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              {getPostedTimeAgo(job.postedDate)}
            </span>
            <div className="flex-grow"></div>
            <Button 
              variant="link" 
              size="sm" 
              className="text-primary dark:text-primary-light font-medium hover:underline"
              onClick={() => onViewJob && onViewJob(job)}
            >
              View
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobCard;
