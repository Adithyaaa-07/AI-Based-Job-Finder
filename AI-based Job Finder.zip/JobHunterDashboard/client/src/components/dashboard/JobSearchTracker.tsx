import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  CheckCircle2, 
  Clock, 
  FileSearch, 
  Send, 
  ThumbsUp, 
  UserCheck, 
  XCircle,
  TrendingUp,
  BarChart
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

// Types for application stages and statistics
interface ApplicationStage {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  count: number;
  applications: ApplicationItem[];
}

interface ApplicationItem {
  id: number;
  jobTitle: string;
  company: string;
  date: string;
  status: string;
  stage: string;
  nextSteps?: string;
  feedback?: string;
}

interface ActivityLog {
  id: number;
  type: 'application' | 'interview' | 'offer' | 'rejection' | 'other';
  title: string;
  message: string;
  date: string;
}

interface ApplicationStats {
  totalApplications: number;
  interviews: number;
  offers: number;
  rejections: number;
  responseRate: number;
  averageResponseTime: number;
}

// Sample data for demonstration
const mockStages: ApplicationStage[] = [
  {
    id: "applied",
    name: "Applied",
    description: "Applications submitted",
    icon: <Send className="h-5 w-5" />,
    color: "bg-blue-500",
    count: 12,
    applications: [
      {
        id: 1,
        jobTitle: "Senior Frontend Developer",
        company: "TechCorp",
        date: "2023-05-10",
        status: "Waiting",
        stage: "applied",
      },
      {
        id: 2,
        jobTitle: "UI/UX Designer",
        company: "DesignHub",
        date: "2023-05-08",
        status: "Reviewed",
        stage: "applied",
      }
    ],
  },
  {
    id: "screening",
    name: "Screening",
    description: "Initial interview/assessment",
    icon: <FileSearch className="h-5 w-5" />,
    color: "bg-purple-500",
    count: 4,
    applications: [
      {
        id: 3,
        jobTitle: "Product Manager",
        company: "InnovateNow",
        date: "2023-04-29",
        status: "Phone Interview",
        stage: "screening",
        nextSteps: "Technical assessment scheduled for 05/15"
      }
    ],
  },
  {
    id: "interview",
    name: "Interview",
    description: "Advanced stages of interviews",
    icon: <UserCheck className="h-5 w-5" />,
    color: "bg-yellow-500",
    count: 3,
    applications: [
      {
        id: 4,
        jobTitle: "Full Stack Developer",
        company: "WebSolutions",
        date: "2023-04-22",
        status: "Final Round",
        stage: "interview",
        nextSteps: "Meeting with CTO on 05/18"
      }
    ],
  },
  {
    id: "offer",
    name: "Offer",
    description: "Received job offers",
    icon: <ThumbsUp className="h-5 w-5" />,
    color: "bg-green-500",
    count: 1,
    applications: [
      {
        id: 5,
        jobTitle: "React Developer",
        company: "AppWorks",
        date: "2023-04-15",
        status: "Negotiating",
        stage: "offer",
        nextSteps: "Reviewing compensation package"
      }
    ],
  },
  {
    id: "rejected",
    name: "Rejected",
    description: "Applications not moved forward",
    icon: <XCircle className="h-5 w-5" />,
    color: "bg-gray-500",
    count: 8,
    applications: [
      {
        id: 6,
        jobTitle: "Frontend Engineer",
        company: "StartupX",
        date: "2023-04-05",
        status: "Closed",
        stage: "rejected",
        feedback: "Selected candidate with more industry experience"
      }
    ],
  }
];

const mockActivityLog: ActivityLog[] = [
  {
    id: 1,
    type: 'application',
    title: 'Applied to Senior Frontend Developer',
    message: 'You submitted an application to TechCorp',
    date: '2023-05-10'
  },
  {
    id: 2,
    type: 'interview',
    title: 'Interview Scheduled',
    message: 'Phone interview with InnovateNow for Product Manager position',
    date: '2023-05-05'
  },
  {
    id: 3,
    type: 'offer',
    title: 'Offer Received',
    message: 'AppWorks has extended an offer for React Developer position',
    date: '2023-04-16'
  },
  {
    id: 4,
    type: 'rejection',
    title: 'Application Rejected',
    message: 'StartupX has decided not to move forward with your application',
    date: '2023-04-07'
  }
];

const mockStats: ApplicationStats = {
  totalApplications: 28,
  interviews: 8,
  offers: 1,
  rejections: 9,
  responseRate: 64,
  averageResponseTime: 7.3
};

// Animation for the progress tracker
const AnimatedProgressBar = ({ value }: { value: number }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setProgress(value), 500);
    return () => clearTimeout(timer);
  }, [value]);

  return <Progress value={progress} className="h-2 transition-all duration-700 ease-in-out" />;
};

// Component for the progress tracker application
const JobSearchTracker = () => {
  const { toast } = useToast();
  const [selectedStage, setSelectedStage] = useState<string>("all");
  const [filteredApplications, setFilteredApplications] = useState<ApplicationItem[]>([]);
  const [stats, setStats] = useState<ApplicationStats>(mockStats);
  const [stages, setStages] = useState<ApplicationStage[]>(mockStages);
  const [activityLog, setActivityLog] = useState<ActivityLog[]>(mockActivityLog);
  
  // This would be a real query in a production environment
  // const { data: applicationData, isLoading } = useQuery({
  //   queryKey: ['/api/applications/tracking'],
  //   queryFn: getQueryFn({ on401: "returnNull" }),
  // });

  useEffect(() => {
    if (selectedStage === "all") {
      const allApps = stages.flatMap(stage => stage.applications);
      setFilteredApplications(allApps);
    } else {
      const stageApps = stages.find(stage => stage.id === selectedStage)?.applications || [];
      setFilteredApplications(stageApps);
    }
  }, [selectedStage, stages]);

  const handleUpdateStatus = (applicationId: number, newStatus: string) => {
    // This would be an API call in a real application
    toast({
      title: "Status Updated",
      description: `Application status changed to: ${newStatus}`
    });
  };

  // Calculate the total completion percentage of the job search
  const calculateProgress = () => {
    const totalWeight = stages.reduce((acc, stage) => {
      // Different weights for different stages
      const weights: Record<string, number> = {
        applied: 1,
        screening: 2,
        interview: 3,
        offer: 4,
        rejected: 0
      };
      return acc + (stage.count * (weights[stage.id] || 0));
    }, 0);
    
    const maxPossibleWeight = stats.totalApplications * 4; // 4 is max weight (offer stage)
    return Math.round((totalWeight / maxPossibleWeight) * 100);
  };

  // Animation for stage transitions
  const getAnimationClass = (stageId: string) => {
    return selectedStage === stageId || selectedStage === "all" 
      ? "opacity-100 transform scale-100 transition-all duration-300 ease-in-out" 
      : "opacity-75 transform scale-95 transition-all duration-300 ease-in-out";
  };

  return (
    <div className="space-y-6">
      <div className="mb-4">
        <h3 className="text-lg font-medium mb-2">Your Job Search Progress</h3>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Progress: {calculateProgress()}%</span>
            <span>{stats.totalApplications} applications</span>
          </div>
          <AnimatedProgressBar value={calculateProgress()} />
        </div>
      </div>

      <Tabs defaultValue="tracker" className="space-y-4">
        <TabsList className="grid grid-cols-3 gap-2">
          <TabsTrigger value="tracker">Progress Tracker</TabsTrigger>
          <TabsTrigger value="stats">Statistics</TabsTrigger>
          <TabsTrigger value="activity">Activity Log</TabsTrigger>
        </TabsList>
        
        <TabsContent value="tracker" className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-5 gap-2">
            <Button
              variant={selectedStage === "all" ? "default" : "outline"}
              className="text-xs"
              onClick={() => setSelectedStage("all")}
            >
              All ({stats.totalApplications})
            </Button>
            
            {stages.map((stage) => (
              <Button
                key={stage.id}
                variant={selectedStage === stage.id ? "default" : "outline"}
                className={`text-xs ${getAnimationClass(stage.id)}`}
                onClick={() => setSelectedStage(stage.id)}
              >
                <span className="flex items-center space-x-1">
                  <span>{stage.icon}</span>
                  <span>{stage.name} ({stage.count})</span>
                </span>
              </Button>
            ))}
          </div>

          <div className="space-y-3 mt-4">
            {filteredApplications.length === 0 ? (
              <div className="text-center py-10 text-gray-500">
                <p>No applications in this stage</p>
              </div>
            ) : (
              filteredApplications.map((app) => (
                <Card 
                  key={app.id} 
                  className={`overflow-hidden ${getAnimationClass(app.stage)} group hover:shadow-md transition-all duration-300`}
                >
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">{app.jobTitle}</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{app.company}</p>
                        <div className="flex items-center mt-2 space-x-2">
                          <Badge variant="outline" className="text-xs">
                            {app.stage.charAt(0).toUpperCase() + app.stage.slice(1)}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            <Clock className="inline h-3 w-3 mr-1" />
                            {app.date}
                          </span>
                        </div>
                      </div>
                      
                      <div className="flex flex-col items-end">
                        <Badge 
                          variant={app.status === "Waiting" ? "outline" : "default"}
                          className={`
                            ${app.status === "Reviewed" ? "bg-blue-500" : ""}
                            ${app.status === "Phone Interview" ? "bg-purple-500" : ""}
                            ${app.status === "Final Round" ? "bg-yellow-500" : ""}
                            ${app.status === "Negotiating" ? "bg-green-500" : ""}
                            ${app.status === "Closed" ? "bg-gray-500" : ""}
                          `}
                        >
                          {app.status}
                        </Badge>
                        
                        <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="text-xs"
                            onClick={() => handleUpdateStatus(app.id, "Updated")}
                          >
                            Update Status
                          </Button>
                        </div>
                      </div>
                    </div>
                    
                    {(app.nextSteps || app.feedback) && (
                      <div className="mt-3 pt-3 border-t border-gray-100 dark:border-gray-800 text-sm">
                        {app.nextSteps && (
                          <p className="flex items-start">
                            <span className="font-medium mr-2">Next Steps:</span> 
                            {app.nextSteps}
                          </p>
                        )}
                        {app.feedback && (
                          <p className="flex items-start mt-1">
                            <span className="font-medium mr-2">Feedback:</span> 
                            {app.feedback}
                          </p>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="stats" className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="space-y-2">
                  <p className="text-sm text-gray-500">Applications to Interview</p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold">{Math.round((stats.interviews / stats.totalApplications) * 100)}%</span>
                    <TrendingUp className="h-5 w-5 text-green-500" />
                  </div>
                  <AnimatedProgressBar value={(stats.interviews / stats.totalApplications) * 100} />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="space-y-2">
                  <p className="text-sm text-gray-500">Interview to Offer</p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold">{stats.interviews ? Math.round((stats.offers / stats.interviews) * 100) : 0}%</span>
                    <BarChart className="h-5 w-5 text-blue-500" />
                  </div>
                  <AnimatedProgressBar value={stats.interviews ? (stats.offers / stats.interviews) * 100 : 0} />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="space-y-2">
                  <p className="text-sm text-gray-500">Response Rate</p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold">{stats.responseRate}%</span>
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                  </div>
                  <AnimatedProgressBar value={stats.responseRate} />
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-4">
            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium mb-4">Application Funnel</h4>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span>Applied</span>
                      <span>{stats.totalApplications}</span>
                    </div>
                    <AnimatedProgressBar value={100} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span>Screening</span>
                      <span>{stats.interviews}</span>
                    </div>
                    <AnimatedProgressBar value={(stats.interviews / stats.totalApplications) * 100} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span>Interview</span>
                      <span>{Math.floor(stats.interviews * 0.6)}</span>
                    </div>
                    <AnimatedProgressBar value={(Math.floor(stats.interviews * 0.6) / stats.totalApplications) * 100} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span>Offer</span>
                      <span>{stats.offers}</span>
                    </div>
                    <AnimatedProgressBar value={(stats.offers / stats.totalApplications) * 100} />
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                  <p className="text-sm text-gray-500">
                    Average response time: <span className="font-medium">{stats.averageResponseTime} days</span>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="activity" className="space-y-4">
          <div className="space-y-4">
            {activityLog.map((activity) => (
              <div key={activity.id} className="flex">
                <div className="mr-4 relative">
                  <div className={`
                    w-8 h-8 rounded-full flex items-center justify-center
                    ${activity.type === 'application' ? 'bg-blue-100 text-blue-600' : ''}
                    ${activity.type === 'interview' ? 'bg-purple-100 text-purple-600' : ''}
                    ${activity.type === 'offer' ? 'bg-green-100 text-green-600' : ''}
                    ${activity.type === 'rejection' ? 'bg-red-100 text-red-600' : ''}
                    ${activity.type === 'other' ? 'bg-gray-100 text-gray-600' : ''}
                  `}>
                    {activity.type === 'application' && <Send className="h-4 w-4" />}
                    {activity.type === 'interview' && <UserCheck className="h-4 w-4" />}
                    {activity.type === 'offer' && <ThumbsUp className="h-4 w-4" />}
                    {activity.type === 'rejection' && <XCircle className="h-4 w-4" />}
                    {activity.type === 'other' && <FileSearch className="h-4 w-4" />}
                  </div>
                  {/* Connecting line */}
                  <div className="absolute left-4 top-8 bottom-0 w-0.5 bg-gray-200 dark:bg-gray-700" style={{ height: 'calc(100% - 2rem)' }}></div>
                </div>
                
                <div className="pb-6 flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium">{activity.title}</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{activity.message}</p>
                    </div>
                    <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap ml-4">{activity.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default JobSearchTracker;