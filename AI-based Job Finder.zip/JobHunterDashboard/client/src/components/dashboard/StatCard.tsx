import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";
import { ArrowDown, ArrowRight, ArrowUp } from "lucide-react";

const iconVariants = cva(
  "p-2 rounded-full",
  {
    variants: {
      color: {
        blue: "bg-blue-100 dark:bg-blue-900/30 text-blue-500 dark:text-blue-400",
        purple: "bg-purple-100 dark:bg-purple-900/30 text-purple-500 dark:text-purple-400",
        yellow: "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-500 dark:text-yellow-400",
        green: "bg-green-100 dark:bg-green-900/30 text-green-500 dark:text-green-400",
        red: "bg-red-100 dark:bg-red-900/30 text-red-500 dark:text-red-400",
      },
    },
    defaultVariants: {
      color: "blue",
    },
  }
);

export interface StatCardProps extends VariantProps<typeof iconVariants> {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  change?: number;
  changeText?: string;
}

const StatCard = ({
  title,
  value,
  icon,
  change,
  changeText,
  color,
}: StatCardProps) => {
  const renderChangeIndicator = () => {
    if (change === undefined) return null;
    
    if (change > 0) {
      return (
        <div className="mt-4 flex items-center text-xs text-green-500 dark:text-green-400">
          <ArrowUp className="h-4 w-4 mr-1" />
          <span>{changeText || `${change}% from last week`}</span>
        </div>
      );
    } else if (change < 0) {
      return (
        <div className="mt-4 flex items-center text-xs text-red-500 dark:text-red-400">
          <ArrowDown className="h-4 w-4 mr-1" />
          <span>{changeText || `${Math.abs(change)}% from last week`}</span>
        </div>
      );
    } else {
      return (
        <div className="mt-4 flex items-center text-xs text-yellow-600 dark:text-yellow-500">
          <ArrowRight className="h-4 w-4 mr-1" />
          <span>{changeText || "Same as last week"}</span>
        </div>
      );
    }
  };

  return (
    <div className="bg-white dark:bg-surface-dark p-5 rounded-lg shadow-card dark:shadow-card-dark">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm text-text-light-secondary dark:text-text-dark-secondary">{title}</p>
          <h3 className="text-2xl font-medium mt-1">{value}</h3>
        </div>
        <div className={cn(iconVariants({ color }))}>
          {icon}
        </div>
      </div>
      {renderChangeIndicator()}
    </div>
  );
};

export default StatCard;
