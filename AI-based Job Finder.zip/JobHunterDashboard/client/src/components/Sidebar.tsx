import { Link, useLocation } from "wouter";
import { 
  BookmarkIcon, 
  BookOpen, 
  BarChart2, 
  Search, 
  FileText,
  User,
  Settings,
  LayoutDashboard,
  LineChart,
  TrendingUp
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const NavItem = ({ href, icon: Icon, text, active, badge }: { 
  href: string; 
  icon: React.ElementType; 
  text: string; 
  active: boolean;
  badge?: number;
}) => {
  return (
    <li className="px-2 mt-1">
      <Link href={href} className={cn(
        "flex items-center px-4 py-3 rounded-md",
        active 
          ? "text-primary dark:text-primary-light bg-primary/5 dark:bg-primary/10" 
          : "text-text-light-primary dark:text-text-dark-primary hover:bg-gray-100 dark:hover:bg-gray-800"
      )}>
        <Icon className="mr-3 h-5 w-5" />
        {text}
        {badge !== undefined && (
          <span className="ml-auto bg-primary text-white text-xs px-2 py-1 rounded-full">
            {badge}
          </span>
        )}
      </Link>
    </li>
  );
};

const Sidebar = () => {
  const [location] = useLocation();

  return (
    <aside className="hidden md:flex w-64 flex-shrink-0 bg-surface-light dark:bg-surface-dark border-r border-gray-200 dark:border-gray-800">
      <div className="h-full flex flex-col">
        <div className="p-4">
          <div className="relative">
            <Search className="absolute inset-y-0 left-3 my-auto h-4 w-4 text-gray-500 dark:text-gray-400" />
            <Input 
              type="text" 
              placeholder="Search jobs..." 
              className="pl-10 pr-4 py-2 w-full rounded-md border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:ring-2 focus:ring-primary focus:border-primary dark:focus:border-primary text-sm dark:text-gray-200" 
            />
          </div>
        </div>
        
        <nav className="flex-1 overflow-y-auto">
          <ul>
            <NavItem 
              href="/dashboard" 
              icon={LayoutDashboard} 
              text="Dashboard" 
              active={location === "/" || location === "/dashboard"} 
            />
            <NavItem 
              href="/profile" 
              icon={User} 
              text="Profile" 
              active={location === "/profile"} 
            />
            <NavItem 
              href="/saved-jobs" 
              icon={BookmarkIcon} 
              text="Saved Jobs" 
              active={location === "/saved-jobs"} 
              badge={8}
            />
            <NavItem 
              href="/applications" 
              icon={FileText} 
              text="Applications" 
              active={location === "/applications"} 
            />
            <NavItem 
              href="/job-tracker" 
              icon={TrendingUp} 
              text="Job Tracker" 
              active={location === "/job-tracker"} 
            />
            <NavItem 
              href="/analytics" 
              icon={BarChart2} 
              text="Analytics" 
              active={location === "/analytics"} 
            />
            <NavItem 
              href="/learning" 
              icon={BookOpen} 
              text="Learning" 
              active={location === "/learning"} 
            />
            <NavItem 
              href="/settings" 
              icon={Settings} 
              text="Settings" 
              active={location === "/settings"} 
            />
          </ul>
        </nav>
        
        <div className="p-4 border-t border-gray-200 dark:border-gray-800">
          <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
            <h4 className="font-medium text-blue-800 dark:text-blue-300 text-sm">AI Assistant</h4>
            <p className="text-sm text-blue-600 dark:text-blue-400 mt-1">Get personalized job advice</p>
            <Button className="mt-2 w-full px-3 py-2 bg-primary text-white rounded-md text-sm hover:bg-primary-dark">
              Ask AI
            </Button>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
