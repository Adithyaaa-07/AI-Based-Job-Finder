import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Search, 
  BookmarkIcon, 
  User 
} from "lucide-react";
import { cn } from "@/lib/utils";

const NavItem = ({ href, icon: Icon, text, active }: { 
  href: string; 
  icon: React.ElementType; 
  text: string; 
  active: boolean;
}) => {
  return (
    <Link href={href}>
      <a className={cn(
        "flex flex-col items-center py-2 px-3",
        active 
          ? "text-primary dark:text-primary-light" 
          : "text-gray-500 dark:text-gray-400"
      )}>
        <Icon className="h-6 w-6" />
        <span className="text-xs mt-1">{text}</span>
      </a>
    </Link>
  );
};

const MobileNav = () => {
  const [location] = useLocation();

  return (
    <nav className="md:hidden bg-white dark:bg-surface-dark border-t border-gray-200 dark:border-gray-800 fixed bottom-0 w-full z-40">
      <div className="flex justify-around">
        <NavItem 
          href="/dashboard" 
          icon={LayoutDashboard} 
          text="Dashboard" 
          active={location === "/" || location === "/dashboard"} 
        />
        <NavItem 
          href="/jobs" 
          icon={Search} 
          text="Search" 
          active={location === "/jobs"} 
        />
        <NavItem 
          href="/saved-jobs" 
          icon={BookmarkIcon} 
          text="Saved" 
          active={location === "/saved-jobs"} 
        />
        <NavItem 
          href="/profile" 
          icon={User} 
          text="Profile" 
          active={location === "/profile"} 
        />
      </div>
    </nav>
  );
};

export default MobileNav;
