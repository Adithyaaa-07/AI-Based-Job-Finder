import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Application, Job } from "../types";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Briefcase, MapPin, DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Applications = () => {
  const { toast } = useToast();
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  
  // Fetch applications
  const { data: applications, isLoading } = useQuery<Application[]>({
    queryKey: ['/api/applications'],
  });
  
  // Format application date
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };
  
  // Get status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Applied':
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400";
      case 'In Review':
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400";
      case 'Rejected':
        return "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400";
      case 'Offered':
        return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200";
    }
  };
  
  // View job details
  const handleViewJob = (job: Job) => {
    setSelectedJob(job);
  };
  
  const handleWithdrawApplication = async (applicationId: number) => {
    try {
      await fetch(`/api/applications/${applicationId}/withdraw`, {
        method: 'POST',
        credentials: 'include',
      });
      toast({
        title: "Application Withdrawn",
        description: "Your application has been withdrawn successfully",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Action Failed",
        description: "There was a problem withdrawing your application",
      });
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Your Applications</h1>
      
      {isLoading ? (
        <div className="h-48 flex items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
        </div>
      ) : applications && applications.length > 0 ? (
        <div className="space-y-4">
          {applications.map((application) => (
            application.job && (
              <Card key={application.id} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                      <div>
                        <h3 className="text-lg font-medium">{application.job.title}</h3>
                        <p className="text-sm text-muted-foreground">{application.job.company}</p>
                      </div>
                      <Badge className={getStatusColor(application.status)}>
                        {application.status}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4 mr-2" />
                        {application.job.location} ({application.job.locationType})
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Briefcase className="h-4 w-4 mr-2" />
                        {application.job.jobType}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <DollarSign className="h-4 w-4 mr-2" />
                        {application.job.salaryMin && application.job.salaryMax ? 
                          `$${application.job.salaryMin.toLocaleString()} - $${application.job.salaryMax.toLocaleString()}` : 
                          "Salary not specified"}
                      </div>
                    </div>
                    
                    <div className="flex items-center text-sm text-muted-foreground mb-4">
                      <Calendar className="h-4 w-4 mr-2" />
                      Applied on {formatDate(application.appliedAt)}
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {application.job.skills.slice(0, 5).map((skill, i) => (
                        <Badge 
                          key={i}
                          variant="secondary"
                          className="text-xs bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 font-normal"
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 justify-end">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleWithdrawApplication(application.id)}
                      >
                        Withdraw
                      </Button>
                      <Button 
                        size="sm"
                        onClick={() => handleViewJob(application.job!)}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          ))}
        </div>
      ) : (
        <div className="text-center py-12 border rounded-lg bg-white dark:bg-surface-dark">
          <h3 className="text-lg font-medium">No applications yet</h3>
          <p className="text-muted-foreground mt-1">Your job applications will appear here</p>
          <Button className="mt-4" onClick={() => window.location.href = '/jobs'}>
            Browse Jobs
          </Button>
        </div>
      )}
      
      {/* Job Detail Dialog */}
      <Dialog open={!!selectedJob} onOpenChange={(open) => !open && setSelectedJob(null)}>
        {selectedJob && (
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{selectedJob.title}</DialogTitle>
              <DialogDescription className="flex items-center">
                <span>{selectedJob.company}</span>
                <span className="mx-2">•</span>
                <span>{selectedJob.location} ({selectedJob.locationType})</span>
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold mb-1">Job Type</h4>
                <p>{selectedJob.jobType}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Salary Range</h4>
                <p>
                  {selectedJob.salaryMin && selectedJob.salaryMax 
                    ? `$${selectedJob.salaryMin.toLocaleString()} - $${selectedJob.salaryMax.toLocaleString()}`
                    : selectedJob.salaryMin
                    ? `From $${selectedJob.salaryMin.toLocaleString()}`
                    : selectedJob.salaryMax
                    ? `Up to $${selectedJob.salaryMax.toLocaleString()}`
                    : "Not specified"
                  }
                </p>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Description</h4>
                <p>{selectedJob.description}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Requirements</h4>
                <ul className="list-disc pl-5 space-y-1">
                  {selectedJob.requirements.map((req, i) => (
                    <li key={i}>{req}</li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedJob.skills.map((skill, i) => (
                    <div key={i} className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-full">
                      {skill}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedJob(null)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
};

export default Applications;
