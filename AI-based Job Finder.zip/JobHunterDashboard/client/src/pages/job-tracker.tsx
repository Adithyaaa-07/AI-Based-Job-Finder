import { useState } from "react";
import Layout from "../components/Layout";
import JobSearchTracker from "../components/dashboard/JobSearchTracker";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusCircle, TrendingUp, CheckCircle, BarChart2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

// Stats data for the summary cards
const summaryStats = {
  activeApplications: 12,
  interviewsScheduled: 4,
  offersReceived: 1,
  applicationCompletionRate: 68
};

const JobTracker = () => {
  const { toast } = useToast();
  const [addApplicationDialogOpen, setAddApplicationDialogOpen] = useState(false);
  const [newApplication, setNewApplication] = useState({
    jobTitle: "",
    company: "",
    status: "Applied",
    location: "",
    date: new Date().toISOString().split('T')[0]
  });

  const handleAddApplication = () => {
    if (!newApplication.jobTitle || !newApplication.company) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    // This would be an API call in a real application
    toast({
      title: "Application Added",
      description: "Your job application has been successfully tracked"
    });
    
    setAddApplicationDialogOpen(false);
    setNewApplication({
      jobTitle: "",
      company: "",
      status: "Applied",
      location: "",
      date: new Date().toISOString().split('T')[0]
    });
  };

  return (
    <Layout>
      <div className="flex flex-col space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Job Application Tracker</h1>
          <Dialog open={addApplicationDialogOpen} onOpenChange={setAddApplicationDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center">
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Application
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Track New Job Application</DialogTitle>
                <DialogDescription>
                  Add details about a job you've applied to for tracking.
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="jobTitle">Job Title</Label>
                  <Input 
                    id="jobTitle" 
                    value={newApplication.jobTitle}
                    onChange={(e) => setNewApplication({...newApplication, jobTitle: e.target.value})}
                    placeholder="e.g. Frontend Developer"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="company">Company</Label>
                  <Input 
                    id="company" 
                    value={newApplication.company}
                    onChange={(e) => setNewApplication({...newApplication, company: e.target.value})}
                    placeholder="e.g. Tech Company Inc."
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="status">Status</Label>
                    <Select 
                      value={newApplication.status}
                      onValueChange={(value) => setNewApplication({...newApplication, status: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectGroup>
                          <SelectItem value="Applied">Applied</SelectItem>
                          <SelectItem value="Screening">Screening</SelectItem>
                          <SelectItem value="Interview">Interview</SelectItem>
                          <SelectItem value="Offer">Offer</SelectItem>
                          <SelectItem value="Rejected">Rejected</SelectItem>
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="date">Application Date</Label>
                    <Input 
                      id="date" 
                      type="date"
                      value={newApplication.date}
                      onChange={(e) => setNewApplication({...newApplication, date: e.target.value})}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <Input 
                    id="location" 
                    value={newApplication.location}
                    onChange={(e) => setNewApplication({...newApplication, location: e.target.value})}
                    placeholder="e.g. Remote, New York, NY"
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setAddApplicationDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddApplication}>
                  Add Application
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Active Applications</p>
                  <p className="text-2xl font-bold">{summaryStats.activeApplications}</p>
                </div>
                <div className="p-2 bg-blue-50 dark:bg-blue-900/20 rounded-full">
                  <TrendingUp className="h-5 w-5 text-blue-500" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Interviews Scheduled</p>
                  <p className="text-2xl font-bold">{summaryStats.interviewsScheduled}</p>
                </div>
                <div className="p-2 bg-purple-50 dark:bg-purple-900/20 rounded-full">
                  <BarChart2 className="h-5 w-5 text-purple-500" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Offers Received</p>
                  <p className="text-2xl font-bold">{summaryStats.offersReceived}</p>
                </div>
                <div className="p-2 bg-green-50 dark:bg-green-900/20 rounded-full">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Completion Rate</p>
                  <p className="text-2xl font-bold">{summaryStats.applicationCompletionRate}%</p>
                </div>
                <div className="p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded-full">
                  <BarChart2 className="h-5 w-5 text-yellow-500" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Application Progress Tracker</CardTitle>
          </CardHeader>
          <CardContent>
            <JobSearchTracker />
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default JobTracker;