import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Job, SavedJob } from "../types";
import JobCard from "../components/dashboard/JobCard";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const SavedJobs = () => {
  const { toast } = useToast();
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  
  // Fetch saved jobs
  const { data: savedJobs, isLoading } = useQuery<SavedJob[]>({
    queryKey: ['/api/saved-jobs'],
  });
  
  // View job details
  const handleViewJob = (job: Job) => {
    setSelectedJob(job);
  };
  
  // Apply for job
  const handleApplyForJob = async () => {
    if (!selectedJob) return;
    try {
      await fetch(`/api/jobs/${selectedJob.id}/apply`, {
        method: 'POST',
        credentials: 'include',
      });
      toast({
        title: "Application Submitted",
        description: "Your application has been submitted successfully",
      });
      setSelectedJob(null);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Application Failed",
        description: "There was a problem submitting your application",
      });
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Saved Jobs</h1>
      
      {isLoading ? (
        <div className="h-48 flex items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
        </div>
      ) : savedJobs && savedJobs.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {savedJobs.map((savedJob) => (
            savedJob.job && (
              <JobCard 
                key={savedJob.id} 
                job={savedJob.job} 
                isSaved={true}
                onViewJob={handleViewJob}
              />
            )
          ))}
        </div>
      ) : (
        <div className="text-center py-12 border rounded-lg bg-white dark:bg-surface-dark">
          <h3 className="text-lg font-medium">No saved jobs yet</h3>
          <p className="text-muted-foreground mt-1">Your saved jobs will appear here</p>
          <Button className="mt-4" onClick={() => window.location.href = '/jobs'}>
            Browse Jobs
          </Button>
        </div>
      )}
      
      {/* Job Detail Dialog */}
      <Dialog open={!!selectedJob} onOpenChange={(open) => !open && setSelectedJob(null)}>
        {selectedJob && (
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{selectedJob.title}</DialogTitle>
              <DialogDescription className="flex items-center">
                <span>{selectedJob.company}</span>
                <span className="mx-2">•</span>
                <span>{selectedJob.location} ({selectedJob.locationType})</span>
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold mb-1">Job Type</h4>
                <p>{selectedJob.jobType}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Salary Range</h4>
                <p>
                  {selectedJob.salaryMin && selectedJob.salaryMax 
                    ? `$${selectedJob.salaryMin.toLocaleString()} - $${selectedJob.salaryMax.toLocaleString()}`
                    : selectedJob.salaryMin
                    ? `From $${selectedJob.salaryMin.toLocaleString()}`
                    : selectedJob.salaryMax
                    ? `Up to $${selectedJob.salaryMax.toLocaleString()}`
                    : "Not specified"
                  }
                </p>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Description</h4>
                <p>{selectedJob.description}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Requirements</h4>
                <ul className="list-disc pl-5 space-y-1">
                  {selectedJob.requirements.map((req, i) => (
                    <li key={i}>{req}</li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedJob.skills.map((skill, i) => (
                    <div key={i} className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-full">
                      {skill}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedJob(null)}>
                Close
              </Button>
              <Button onClick={handleApplyForJob}>
                Apply Now
              </Button>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
};

export default SavedJobs;
