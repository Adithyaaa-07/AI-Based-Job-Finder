import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Job, JobFilters as JobFiltersType } from "../types";
import JobFilters from "../components/dashboard/JobFilters";
import JobCard from "../components/dashboard/JobCard";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

const Jobs = () => {
  const { toast } = useToast();
  const [filtersVisible, setFiltersVisible] = useState(false);
  const [jobFilters, setJobFilters] = useState<JobFiltersType>({});
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  
  // Fetch jobs
  const { data: jobs, isLoading } = useQuery<Job[]>({
    queryKey: ['/api/jobs', jobFilters],
  });
  
  // Apply filters
  const handleApplyFilters = (filters: JobFiltersType) => {
    setJobFilters(filters);
    setFiltersVisible(false);
    toast({
      description: "Filters applied successfully",
    });
  };
  
  // Clear filters
  const handleClearFilters = () => {
    setJobFilters({});
    toast({
      description: "Filters cleared",
    });
  };
  
  // View job details
  const handleViewJob = (job: Job) => {
    setSelectedJob(job);
  };
  
  // Apply for job
  const handleApplyForJob = async () => {
    if (!selectedJob) return;
    try {
      await fetch(`/api/jobs/${selectedJob.id}/apply`, {
        method: 'POST',
        credentials: 'include',
      });
      toast({
        title: "Application Submitted",
        description: "Your application has been submitted successfully",
      });
      setSelectedJob(null);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Application Failed",
        description: "There was a problem submitting your application",
      });
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Browse Jobs</h1>
      
      {/* Filters */}
      <JobFilters 
        filters={jobFilters}
        onApplyFilters={handleApplyFilters}
        onClearFilters={handleClearFilters}
        isVisible={filtersVisible}
        toggleVisibility={() => setFiltersVisible(!filtersVisible)}
      />
      
      {/* Job Listings */}
      {isLoading ? (
        <div className="h-48 flex items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
        </div>
      ) : jobs && jobs.length > 0 ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
            {jobs.map((job) => (
              <JobCard 
                key={job.id} 
                job={job} 
                onViewJob={handleViewJob}
              />
            ))}
          </div>
          
          <div className="mt-6 flex justify-center">
            <Button>Load More</Button>
          </div>
        </>
      ) : (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium">No jobs found</h3>
          <p className="text-muted-foreground mt-1">Try adjusting your filters or search criteria</p>
        </div>
      )}
      
      {/* Job Detail Dialog */}
      <Dialog open={!!selectedJob} onOpenChange={(open) => !open && setSelectedJob(null)}>
        {selectedJob && (
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{selectedJob.title}</DialogTitle>
              <DialogDescription className="flex items-center">
                <span>{selectedJob.company}</span>
                <span className="mx-2">•</span>
                <span>{selectedJob.location} ({selectedJob.locationType})</span>
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold mb-1">Job Type</h4>
                <p>{selectedJob.jobType}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Salary Range</h4>
                <p>
                  {selectedJob.salaryMin && selectedJob.salaryMax 
                    ? `$${selectedJob.salaryMin.toLocaleString()} - $${selectedJob.salaryMax.toLocaleString()}`
                    : selectedJob.salaryMin
                    ? `From $${selectedJob.salaryMin.toLocaleString()}`
                    : selectedJob.salaryMax
                    ? `Up to $${selectedJob.salaryMax.toLocaleString()}`
                    : "Not specified"
                  }
                </p>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Description</h4>
                <p>{selectedJob.description}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Requirements</h4>
                <ul className="list-disc pl-5 space-y-1">
                  {selectedJob.requirements.map((req, i) => (
                    <li key={i}>{req}</li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedJob.skills.map((skill, i) => (
                    <div key={i} className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-full">
                      {skill}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedJob(null)}>
                Close
              </Button>
              <Button onClick={handleApplyForJob}>
                Apply Now
              </Button>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
};

export default Jobs;
