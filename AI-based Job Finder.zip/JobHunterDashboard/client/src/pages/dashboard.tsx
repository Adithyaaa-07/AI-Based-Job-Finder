import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Briefcase, BookmarkIcon, Send, Eye, TrendingUp, DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import StatCard from "../components/dashboard/StatCard";
import SkillsAnalysis from "../components/dashboard/SkillsAnalysis";
import SkillGapRecommendations from "../components/dashboard/SkillGapRecommendations";
import JobFilters from "../components/dashboard/JobFilters";
import JobCard from "../components/dashboard/JobCard";
import CareerInsights from "../components/dashboard/CareerInsights";
import SalaryPredictor from "../components/dashboard/SalaryPredictor";
import { DashboardStats, Job, JobFilters as JobFiltersType, Recommendation, Skill, TopSkill, CareerEvent } from "../types";

const Dashboard = () => {
  const { toast } = useToast();
  const [filtersVisible, setFiltersVisible] = useState(false);
  const [jobFilters, setJobFilters] = useState<JobFiltersType>({});
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  
  // Fetch dashboard stats
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
  });
  
  // Fetch user skills
  const { data: skills, isLoading: skillsLoading } = useQuery<{ skills: Skill[], match: number }>({
    queryKey: ['/api/dashboard/skills'],
  });
  
  // Fetch job recommendations
  const { data: recommendations, isLoading: recommendationsLoading } = useQuery<Recommendation[]>({
    queryKey: ['/api/dashboard/recommendations'],
  });
  
  // Fetch matched jobs
  const { data: jobs, isLoading: jobsLoading } = useQuery<Job[]>({
    queryKey: ['/api/jobs/matched'],
  });
  
  // Fetch top skills
  const { data: topSkills, isLoading: topSkillsLoading } = useQuery<TopSkill[]>({
    queryKey: ['/api/dashboard/top-skills'],
  });
  
  // Fetch career events
  const { data: events, isLoading: eventsLoading } = useQuery<CareerEvent[]>({
    queryKey: ['/api/dashboard/events'],
  });
  
  // Apply filters
  const handleApplyFilters = (filters: JobFiltersType) => {
    setJobFilters(filters);
    setFiltersVisible(false);
    toast({
      description: "Filters applied successfully",
    });
  };
  
  // Clear filters
  const handleClearFilters = () => {
    setJobFilters({});
    toast({
      description: "Filters cleared",
    });
  };
  
  // View job details
  const handleViewJob = (job: Job) => {
    setSelectedJob(job);
  };
  
  // Apply for job
  const handleApplyForJob = async () => {
    if (!selectedJob) return;
    try {
      await fetch(`/api/jobs/${selectedJob.id}/apply`, {
        method: 'POST',
        credentials: 'include',
      });
      toast({
        title: "Application Submitted",
        description: "Your application has been submitted successfully",
      });
      setSelectedJob(null);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Application Failed",
        description: "There was a problem submitting your application",
      });
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard
          title="Jobs Matched"
          value={statsLoading ? "..." : stats?.matchedJobs || 0}
          icon={<TrendingUp className="h-5 w-5" />}
          color="blue"
          change={statsLoading ? undefined : stats?.matchedJobsChange}
        />
        <StatCard
          title="Applications"
          value={statsLoading ? "..." : stats?.applications || 0}
          icon={<Send className="h-5 w-5" />}
          color="purple"
          change={statsLoading ? undefined : stats?.applicationsChange}
        />
        <StatCard
          title="Saved Jobs"
          value={statsLoading ? "..." : stats?.savedJobs || 0}
          icon={<BookmarkIcon className="h-5 w-5" />}
          color="yellow"
          change={statsLoading ? undefined : stats?.savedJobsChange}
          changeText={statsLoading ? undefined : `${stats?.savedJobsChange} new this week`}
        />
        <StatCard
          title="Profile Views"
          value={statsLoading ? "..." : stats?.profileViews || 0}
          icon={<Eye className="h-5 w-5" />}
          color="green"
          change={statsLoading ? undefined : stats?.profileViewsChange}
          changeText={statsLoading ? undefined : `${stats?.profileViewsChange}% increase`}
        />
      </div>
      
      {/* AI Match Section */}
      <div className="mb-6">
        <div className="bg-white dark:bg-surface-dark p-5 rounded-lg shadow-card dark:shadow-card-dark">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium">Your AI Job Match</h2>
            <Button variant="link" className="text-primary dark:text-primary-light hover:underline text-sm">
              Update Preferences
            </Button>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {skillsLoading ? (
              <div className="col-span-1 lg:col-span-3 h-48 flex items-center justify-center">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              </div>
            ) : (
              <>
                <SkillsAnalysis 
                  skills={skills?.skills || []} 
                  overallMatch={skills?.match || 0} 
                />
                <SkillGapRecommendations 
                  recommendations={recommendations || []} 
                  insightText="Based on your profile and current job market trends, improving your Cloud Services skills could increase your job matches by 30%."
                />
              </>
            )}
          </div>
        </div>
      </div>
      
      {/* Salary Predictor Section */}
      <div className="mb-6">
        <div className="bg-white dark:bg-surface-dark p-5 rounded-lg shadow-card dark:shadow-card-dark">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium flex items-center">
              <DollarSign className="h-5 w-5 mr-2 text-green-500" />
              Salary Predictor
            </h2>
            <div className="px-2 py-1 text-xs bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full">
              Based on Market Data
            </div>
          </div>
          
          <SalaryPredictor />
        </div>
      </div>
      
      {/* Job Listings */}
      <div className="mb-6">
        <JobFilters 
          filters={jobFilters}
          onApplyFilters={handleApplyFilters}
          onClearFilters={handleClearFilters}
          isVisible={filtersVisible}
          toggleVisibility={() => setFiltersVisible(!filtersVisible)}
        />
        
        {jobsLoading ? (
          <div className="h-48 flex items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {jobs?.map((job) => (
                <JobCard 
                  key={job.id} 
                  job={job} 
                  onViewJob={handleViewJob}
                />
              ))}
            </div>
            
            <div className="mt-6 flex justify-center">
              <Button>View More Jobs</Button>
            </div>
          </>
        )}
      </div>
      
      {/* Career Insights */}
      {topSkillsLoading || eventsLoading ? (
        <div className="h-48 flex items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
        </div>
      ) : (
        <CareerInsights topSkills={topSkills || []} events={events || []} />
      )}
      
      {/* Job Detail Dialog */}
      <Dialog open={!!selectedJob} onOpenChange={(open) => !open && setSelectedJob(null)}>
        {selectedJob && (
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{selectedJob.title}</DialogTitle>
              <DialogDescription className="flex items-center">
                <span>{selectedJob.company}</span>
                <span className="mx-2">•</span>
                <span>{selectedJob.location} ({selectedJob.locationType})</span>
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold mb-1">Job Type</h4>
                <p>{selectedJob.jobType}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Salary Range</h4>
                <p>
                  {selectedJob.salaryMin && selectedJob.salaryMax 
                    ? `$${selectedJob.salaryMin.toLocaleString()} - $${selectedJob.salaryMax.toLocaleString()}`
                    : selectedJob.salaryMin
                    ? `From $${selectedJob.salaryMin.toLocaleString()}`
                    : selectedJob.salaryMax
                    ? `Up to $${selectedJob.salaryMax.toLocaleString()}`
                    : "Not specified"
                  }
                </p>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Description</h4>
                <p>{selectedJob.description}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Requirements</h4>
                <ul className="list-disc pl-5 space-y-1">
                  {selectedJob.requirements.map((req, i) => (
                    <li key={i}>{req}</li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="text-sm font-semibold mb-1">Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedJob.skills.map((skill, i) => (
                    <div key={i} className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-full">
                      {skill}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedJob(null)}>
                Close
              </Button>
              <Button onClick={handleApplyForJob}>
                Apply Now
              </Button>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
};

export default Dashboard;
