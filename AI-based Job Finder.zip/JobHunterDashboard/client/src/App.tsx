import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useEffect } from "react";

import Layout from "./components/Layout";
import Login from "./pages/login";
import Register from "./pages/register";
import Dashboard from "./pages/dashboard";
import Profile from "./pages/profile";
import Jobs from "./pages/jobs";
import SavedJobs from "./pages/saved-jobs";
import Applications from "./pages/applications";
import JobTracker from "./pages/job-tracker";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "./hooks/useAuth";

function App() {
  const [location] = useLocation();
  
  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  const isAuthPage = location === '/login' || location === '/register';

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          {isAuthPage ? (
            <Switch>
              <Route path="/login" component={Login} />
              <Route path="/register" component={Register} />
              <Route component={Login} />
            </Switch>
          ) : (
            <Layout>
              <Switch>
                <Route path="/" component={Dashboard} />
                <Route path="/dashboard" component={Dashboard} />
                <Route path="/profile" component={Profile} />
                <Route path="/jobs" component={Jobs} />
                <Route path="/saved-jobs" component={SavedJobs} />
                <Route path="/applications" component={Applications} />
                <Route path="/job-tracker" component={JobTracker} />
                <Route component={NotFound} />
              </Switch>
            </Layout>
          )}
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
