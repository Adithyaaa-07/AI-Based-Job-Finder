export interface UserProfile {
  id: number;
  username: string;
  email: string;
  fullName: string;
  location?: string;
  title?: string;
  about?: string;
  profileImage?: string;
  skills: string[];
  experience: Experience[];
  education: Education[];
}

export interface Experience {
  title: string;
  company: string;
  startDate: string;
  endDate: string | null;
  description: string;
}

export interface Education {
  degree: string;
  institution: string;
  startDate: string;
  endDate: string | null;
}

export interface Job {
  id: number;
  title: string;
  company: string;
  companyLogo?: string;
  location: string;
  locationType: 'Remote' | 'On-site' | 'Hybrid';
  jobType: 'Full-time' | 'Part-time' | 'Contract';
  description: string;
  requirements: string[];
  responsibilities: string[];
  skills: string[];
  salaryMin?: number;
  salaryMax?: number;
  experienceLevel?: 'Entry' | 'Mid' | 'Senior';
  postedDate: string;
  matchPercentage?: number; // Added for UI display
}

export interface SavedJob {
  id: number;
  userId: number;
  jobId: number;
  savedAt: string;
  job?: Job;
}

export interface Application {
  id: number;
  userId: number;
  jobId: number;
  status: 'Applied' | 'In Review' | 'Rejected' | 'Offered';
  appliedAt: string;
  job?: Job;
}

export interface Skill {
  name: string;
  level: number; // 0-100
}

export interface SkillGap {
  skill: string;
  currentLevel: number;
  requiredLevel: number;
  impact: 'High' | 'Medium' | 'Low';
}

export interface JobFilters {
  location?: string;
  jobType?: ('Full-time' | 'Part-time' | 'Contract')[];
  locationType?: ('Remote' | 'On-site' | 'Hybrid')[];
  experienceLevel?: ('Entry' | 'Mid' | 'Senior')[];
  salaryMin?: number;
  salaryMax?: number;
  skills?: string[];
  postedWithin?: 'day' | 'week' | 'month' | 'all';
}

export interface Recommendation {
  title: string;
  description: string;
  impactLevel: 'High' | 'Medium' | 'Long-term';
}

export interface CareerEvent {
  id: number;
  title: string;
  date: string;
  time: string;
  location: string;
  isVirtual: boolean;
}

export interface TopSkill {
  name: string;
  percentage: number;
}

export interface DashboardStats {
  matchedJobs: number;
  applications: number;
  savedJobs: number;
  profileViews: number;
  matchedJobsChange: number;
  applicationsChange: number;
  savedJobsChange: number;
  profileViewsChange: number;
}
