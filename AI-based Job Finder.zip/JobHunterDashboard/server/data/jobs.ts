import { InsertJob } from "@shared/schema";

export const mockJobs: InsertJob[] = [
  {
    title: "Senior Frontend Developer",
    company: "TechCorp Inc.",
    companyLogo: "https://example.com/techcorp-logo.png",
    location: "San Francisco, CA",
    locationType: "Remote",
    jobType: "Full-time",
    description: "TechCorp is looking for an experienced Frontend Developer to join our team. You will be responsible for building user interfaces for web applications, implementing responsive designs, and optimizing application performance.",
    requirements: [
      "5+ years of experience with modern JavaScript frameworks",
      "Strong knowledge of React and TypeScript",
      "Experience with state management libraries like Redux",
      "Understanding of web performance optimization",
      "Experience with RESTful APIs and GraphQL"
    ],
    responsibilities: [
      "Develop new user-facing features",
      "Build reusable components for future use",
      "Optimize applications for maximum speed and scalability",
      "Collaborate with back-end developers and designers",
      "Maintain code quality and organization"
    ],
    skills: ["React", "TypeScript", "Redux", "JavaScript", "HTML", "CSS"],
    salaryMin: 120000,
    salaryMax: 150000,
    experienceLevel: "Senior",
  },
  {
    title: "Full Stack Developer",
    company: "InnovateLabs",
    companyLogo: "https://example.com/innovatelabs-logo.png",
    location: "New York, NY",
    locationType: "Hybrid",
    jobType: "Full-time",
    description: "InnovateLabs is seeking a skilled Full Stack Developer to work on our core products. The ideal candidate has experience with both front-end and back-end technologies and can work independently.",
    requirements: [
      "3+ years of experience in full-stack development",
      "Strong knowledge of JavaScript and Node.js",
      "Experience with React or similar frameworks",
      "Understanding of database technologies (MongoDB, PostgreSQL)",
      "Familiarity with cloud services (AWS, Azure)"
    ],
    responsibilities: [
      "Develop and maintain web applications",
      "Write clean, maintainable, and efficient code",
      "Collaborate with the team to design and implement new features",
      "Ensure application performance and responsiveness",
      "Debug and fix issues in existing applications"
    ],
    skills: ["JavaScript", "Node.js", "React", "MongoDB", "Express", "AWS"],
    salaryMin: 100000,
    salaryMax: 130000,
    experienceLevel: "Mid",
  },
  {
    title: "React Native Developer",
    company: "MobileFirst Co.",
    companyLogo: "https://example.com/mobilefirst-logo.png",
    location: "Remote",
    locationType: "Remote",
    jobType: "Contract",
    description: "MobileFirst is looking for a React Native developer to help build cross-platform mobile applications. You'll work with a team of designers and developers to create intuitive and efficient apps.",
    requirements: [
      "2+ years of experience with React Native",
      "Experience with native app development for iOS and Android",
      "Knowledge of JavaScript/TypeScript",
      "Understanding of RESTful APIs",
      "Experience with state management libraries"
    ],
    responsibilities: [
      "Develop mobile applications using React Native",
      "Optimize applications for performance",
      "Implement responsive UI designs",
      "Integrate with back-end services",
      "Publish apps to App Store and Google Play"
    ],
    skills: ["React Native", "JavaScript", "Redux", "iOS", "Android", "API Integration"],
    salaryMin: 90000,
    salaryMax: 110000,
    experienceLevel: "Mid",
  },
  {
    title: "UI/UX Designer",
    company: "DesignHub",
    companyLogo: "https://example.com/designhub-logo.png",
    location: "Austin, TX",
    locationType: "On-site",
    jobType: "Full-time",
    description: "DesignHub is looking for a talented UI/UX Designer to create amazing user experiences. The ideal candidate should have a strong portfolio showcasing their design skills and understanding of user-centered design principles.",
    requirements: [
      "3+ years of experience in UI/UX design",
      "Proficiency with design tools (Figma, Sketch)",
      "Understanding of user research and testing",
      "Knowledge of design systems and component libraries",
      "Basic understanding of HTML/CSS"
    ],
    responsibilities: [
      "Create wireframes, prototypes, and high-fidelity designs",
      "Conduct user research and usability testing",
      "Collaborate with developers to implement designs",
      "Maintain and extend design systems",
      "Stay up-to-date with design trends and best practices"
    ],
    skills: ["Figma", "UI/UX", "Prototyping", "User Research", "Wireframing", "Design Systems"],
    salaryMin: 80000,
    salaryMax: 100000,
    experienceLevel: "Mid",
  },
  {
    title: "Backend Developer",
    company: "ServerPro Inc.",
    companyLogo: "https://example.com/serverpro-logo.png",
    location: "Seattle, WA",
    locationType: "Hybrid",
    jobType: "Full-time",
    description: "ServerPro is hiring a Backend Developer to work on our cloud infrastructure. The role involves designing, implementing, and maintaining server-side applications and databases.",
    requirements: [
      "4+ years of experience in backend development",
      "Strong knowledge of Node.js and Express",
      "Experience with MongoDB and SQL databases",
      "Understanding of AWS services",
      "Knowledge of microservices architecture"
    ],
    responsibilities: [
      "Design and implement server-side applications",
      "Develop database schemas and data models",
      "Optimize applications for performance and scalability",
      "Implement security and data protection measures",
      "Write technical documentation"
    ],
    skills: ["Node.js", "MongoDB", "AWS", "Express", "API Development", "Microservices"],
    salaryMin: 110000,
    salaryMax: 140000,
    experienceLevel: "Senior",
  },
  {
    title: "Data Scientist",
    company: "DataInsight Corp",
    companyLogo: "https://example.com/datainsight-logo.png",
    location: "Boston, MA",
    locationType: "Hybrid",
    jobType: "Full-time",
    description: "DataInsight is seeking a Data Scientist to analyze large datasets and develop machine learning models. The ideal candidate has a strong background in statistics and programming.",
    requirements: [
      "Master's or PhD in Statistics, Computer Science, or related field",
      "Experience with Python and data science libraries",
      "Knowledge of machine learning algorithms",
      "Experience with big data technologies",
      "Strong analytical and problem-solving skills"
    ],
    responsibilities: [
      "Analyze large datasets to extract insights",
      "Develop machine learning models for prediction tasks",
      "Create data visualizations and reports",
      "Collaborate with engineering and product teams",
      "Stay current with advances in data science and AI"
    ],
    skills: ["Python", "Machine Learning", "SQL", "Data Analysis", "Statistics", "TensorFlow"],
    salaryMin: 130000,
    salaryMax: 160000,
    experienceLevel: "Senior",
  },
  {
    title: "DevOps Engineer",
    company: "CloudOps Solutions",
    companyLogo: "https://example.com/cloudops-logo.png",
    location: "Chicago, IL",
    locationType: "Remote",
    jobType: "Full-time",
    description: "CloudOps is looking for a DevOps Engineer to help automate and streamline our operations and processes. You will work on cloud infrastructure, CI/CD pipelines, and monitoring systems.",
    requirements: [
      "3+ years of experience in DevOps or SRE roles",
      "Experience with cloud providers (AWS, Azure, or GCP)",
      "Knowledge of containerization and orchestration tools",
      "Experience with CI/CD pipelines",
      "Scripting and automation skills"
    ],
    responsibilities: [
      "Design and implement cloud infrastructure",
      "Automate deployment and scaling processes",
      "Set up monitoring and alerting systems",
      "Troubleshoot production issues",
      "Collaborate with development teams to improve deployment processes"
    ],
    skills: ["AWS", "Docker", "Kubernetes", "CI/CD", "Terraform", "Linux"],
    salaryMin: 115000,
    salaryMax: 145000,
    experienceLevel: "Mid",
  },
  {
    title: "Product Manager",
    company: "ProductVision Inc.",
    companyLogo: "https://example.com/productvision-logo.png",
    location: "San Jose, CA",
    locationType: "Hybrid",
    jobType: "Full-time",
    description: "ProductVision is looking for a Product Manager to help define and execute our product strategy. The ideal candidate has a blend of technical understanding and business acumen.",
    requirements: [
      "3+ years of experience in product management",
      "Experience with agile methodologies",
      "Strong analytical and problem-solving skills",
      "Excellent communication and presentation skills",
      "Basic understanding of software development"
    ],
    responsibilities: [
      "Define product vision and strategy",
      "Gather and prioritize product requirements",
      "Work with engineering to deliver features",
      "Analyze market trends and competition",
      "Create product roadmaps and release plans"
    ],
    skills: ["Product Management", "Agile", "User Stories", "Market Analysis", "Roadmapping", "Jira"],
    salaryMin: 125000,
    salaryMax: 155000,
    experienceLevel: "Mid",
  },
  {
    title: "Frontend Developer",
    company: "WebWorks Corp",
    companyLogo: "https://example.com/webworks-logo.png",
    location: "Denver, CO",
    locationType: "Remote",
    jobType: "Full-time",
    description: "WebWorks is seeking a Frontend Developer to build responsive and interactive web applications. You will work closely with designers and backend developers to implement user interfaces.",
    requirements: [
      "2+ years of experience with JavaScript and modern frameworks",
      "Proficiency with HTML and CSS",
      "Experience with React or similar libraries",
      "Knowledge of responsive design principles",
      "Understanding of RESTful APIs"
    ],
    responsibilities: [
      "Implement responsive user interfaces",
      "Translate designs and wireframes into code",
      "Optimize applications for performance",
      "Collaborate with backend developers",
      "Ensure cross-browser compatibility"
    ],
    skills: ["JavaScript", "React", "HTML", "CSS", "REST APIs", "Responsive Design"],
    salaryMin: 85000,
    salaryMax: 110000,
    experienceLevel: "Entry",
  },
  {
    title: "Machine Learning Engineer",
    company: "AICore Systems",
    companyLogo: "https://example.com/aicore-logo.png",
    location: "Remote",
    locationType: "Remote",
    jobType: "Full-time",
    description: "AICore Systems is looking for a Machine Learning Engineer to develop and deploy AI models. You will work on cutting-edge ML projects in various domains.",
    requirements: [
      "Advanced degree in Computer Science, AI, or related field",
      "Strong programming skills in Python",
      "Experience with ML frameworks (TensorFlow, PyTorch)",
      "Understanding of deep learning architectures",
      "Knowledge of data processing techniques"
    ],
    responsibilities: [
      "Design and implement machine learning models",
      "Process and analyze large datasets",
      "Deploy models to production environments",
      "Evaluate model performance and make improvements",
      "Stay current with the latest ML research"
    ],
    skills: ["Python", "TensorFlow", "PyTorch", "Machine Learning", "Deep Learning", "Data Processing"],
    salaryMin: 140000,
    salaryMax: 180000,
    experienceLevel: "Senior",
  },
  {
    title: "QA Engineer",
    company: "QualityFirst Software",
    companyLogo: "https://example.com/qualityfirst-logo.png",
    location: "Portland, OR",
    locationType: "Hybrid",
    jobType: "Full-time",
    description: "QualityFirst is seeking a QA Engineer to ensure the quality of our software products. You will be responsible for developing and executing test plans and automating testing processes.",
    requirements: [
      "2+ years of experience in software testing",
      "Knowledge of testing methodologies",
      "Experience with test automation tools",
      "Basic programming skills",
      "Attention to detail and problem-solving abilities"
    ],
    responsibilities: [
      "Create and execute test plans",
      "Develop automated tests",
      "Report and track bugs",
      "Collaborate with developers to resolve issues",
      "Improve testing processes"
    ],
    skills: ["Manual Testing", "Automated Testing", "Selenium", "JIRA", "Test Planning", "Bug Tracking"],
    salaryMin: 75000,
    salaryMax: 95000,
    experienceLevel: "Mid",
  },
  {
    title: "Junior Web Developer",
    company: "DigitalEdge Inc.",
    companyLogo: "https://example.com/digitaledge-logo.png",
    location: "Atlanta, GA",
    locationType: "On-site",
    jobType: "Full-time",
    description: "DigitalEdge is looking for a Junior Web Developer to join our growing team. This is an excellent opportunity for someone starting their career in web development.",
    requirements: [
      "Basic knowledge of HTML, CSS, and JavaScript",
      "Understanding of responsive design principles",
      "Familiarity with version control systems",
      "Strong problem-solving skills",
      "Willingness to learn and adapt"
    ],
    responsibilities: [
      "Assist in developing website features",
      "Fix bugs and improve existing code",
      "Implement responsive designs",
      "Learn from senior developers",
      "Participate in code reviews"
    ],
    skills: ["HTML", "CSS", "JavaScript", "Responsive Design", "Git", "Web Development"],
    salaryMin: 55000,
    salaryMax: 75000,
    experienceLevel: "Entry",
  }
];
