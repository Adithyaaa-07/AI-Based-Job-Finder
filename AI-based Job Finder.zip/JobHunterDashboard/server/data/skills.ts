import { Skill, Recommendation, CareerEvent, TopSkill } from "../../../client/src/types";

// Mock skills with levels for the dashboard skills analysis
export const mockSkills: Skill[] = [
  { name: "JavaScript", level: 95 },
  { name: "React", level: 90 },
  { name: "Python", level: 75 },
  { name: "Data Analysis", level: 65 },
  { name: "Cloud Services", level: 50 },
  { name: "TypeScript", level: 85 },
  { name: "HTML", level: 95 },
  { name: "CSS", level: 90 },
  { name: "Node.js", level: 80 },
  { name: "Express", level: 80 },
  { name: "MongoDB", level: 70 },
  { name: "AWS", level: 50 },
  { name: "Docker", level: 60 },
  { name: "Git", level: 85 },
  { name: "RESTful APIs", level: 90 },
  { name: "GraphQL", level: 65 },
  { name: "Redux", level: 80 },
  { name: "SQL", level: 75 },
  { name: "UI/UX Design", level: 60 },
  { name: "TensorFlow", level: 40 }
];

// Mock recommendations for skill gap section
export const mockRecommendations: Recommendation[] = [
  {
    title: "AWS Certification",
    description: "Cloud skills are in high demand. AWS certification can boost your qualifications.",
    impactLevel: "High"
  },
  {
    title: "Data Visualization",
    description: "Improve your data analysis skills with visualization tools like Tableau or Power BI.",
    impactLevel: "Medium"
  },
  {
    title: "Machine Learning",
    description: "Adding ML skills to your profile can open up new career opportunities.",
    impactLevel: "Long-term"
  },
  {
    title: "DevOps Practices",
    description: "DevOps knowledge is increasingly important for full-stack developers.",
    impactLevel: "Medium"
  }
];

// Mock career events for insights section
export const mockEvents: CareerEvent[] = [
  {
    id: 1,
    title: "Tech Career Fair 2023",
    date: "2023-06-16",
    time: "10:00 AM - 4:00 PM",
    location: "Virtual Event",
    isVirtual: true
  },
  {
    id: 2,
    title: "Web Development Workshop",
    date: "2023-06-22",
    time: "1:00 PM - 3:00 PM",
    location: "Online",
    isVirtual: true
  },
  {
    id: 3,
    title: "Tech Industry Networking",
    date: "2023-06-30",
    time: "6:00 PM - 9:00 PM",
    location: "San Francisco, CA",
    isVirtual: false
  }
];

// Mock top skills for career insights
export const mockTopSkills: TopSkill[] = [
  { name: "JavaScript", percentage: 82 },
  { name: "React", percentage: 76 },
  { name: "Node.js", percentage: 63 },
  { name: "TypeScript", percentage: 58 },
  { name: "AWS", percentage: 47 }
];
