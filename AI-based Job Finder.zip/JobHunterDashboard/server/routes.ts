import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { authRouter } from "./auth";
import { authenticateUser } from "./middleware";
import { matchJobs } from "./utils/matching";
import { mockJobs } from "./data/jobs";
import { mockSkills, mockRecommendations, mockEvents, mockTopSkills } from "./data/skills";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.use("/api/auth", authRouter);

  // User profile routes
  app.get("/api/profile", authenticateUser, async (req, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't send password in response
      const { password, ...userProfile } = user;
      res.json(userProfile);
    } catch (error) {
      res.status(500).json({ message: "Error fetching profile" });
    }
  });

  app.patch("/api/profile", authenticateUser, async (req, res) => {
    try {
      const updatedUser = await storage.updateUser(req.user!.id, req.body);
      const { password, ...userProfile } = updatedUser;
      res.json(userProfile);
    } catch (error) {
      res.status(500).json({ message: "Error updating profile" });
    }
  });

  // Dashboard routes
  app.get("/api/dashboard/stats", authenticateUser, async (req, res) => {
    try {
      const jobsCount = await storage.countMatchedJobsForUser(req.user!.id);
      const applicationsCount = await storage.countApplicationsByUser(req.user!.id);
      const savedJobsCount = await storage.countSavedJobsByUser(req.user!.id);

      // Mock data for the dashboard stats
      const stats = {
        matchedJobs: jobsCount,
        applications: applicationsCount,
        savedJobs: savedJobsCount,
        profileViews: 42,
        matchedJobsChange: 12,
        applicationsChange: 0,
        savedJobsChange: 3,
        profileViewsChange: 28
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Error fetching dashboard stats" });
    }
  });

  app.get("/api/dashboard/skills", authenticateUser, async (req, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return user skills with mock skill levels
      const userSkills = user.skills || [];
      const skillsWithLevels = mockSkills.filter(skill => 
        userSkills.includes(skill.name)
      );
      
      res.json({
        skills: skillsWithLevels,
        match: 85 // Mock overall match percentage
      });
    } catch (error) {
      res.status(500).json({ message: "Error fetching skills" });
    }
  });

  app.get("/api/dashboard/recommendations", authenticateUser, async (req, res) => {
    try {
      res.json(mockRecommendations);
    } catch (error) {
      res.status(500).json({ message: "Error fetching recommendations" });
    }
  });

  app.get("/api/dashboard/events", authenticateUser, (req, res) => {
    res.json(mockEvents);
  });

  app.get("/api/dashboard/top-skills", authenticateUser, (req, res) => {
    res.json(mockTopSkills);
  });

  // Jobs routes
  app.get("/api/jobs", authenticateUser, async (req, res) => {
    try {
      const filters = req.query;
      const jobs = await storage.getJobs(filters);
      
      // Enhance jobs with match percentages based on user skills
      const user = await storage.getUser(req.user!.id);
      const jobsWithMatch = matchJobs(jobs, user?.skills || []);
      
      res.json(jobsWithMatch);
    } catch (error) {
      res.status(500).json({ message: "Error fetching jobs" });
    }
  });

  app.get("/api/jobs/matched", authenticateUser, async (req, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const jobs = await storage.getJobs({});
      const matchedJobs = matchJobs(jobs, user.skills || [])
        .filter(job => job.matchPercentage && job.matchPercentage >= 65)
        .sort((a, b) => (b.matchPercentage || 0) - (a.matchPercentage || 0))
        .slice(0, 6);
      
      res.json(matchedJobs);
    } catch (error) {
      res.status(500).json({ message: "Error fetching matched jobs" });
    }
  });

  app.post("/api/jobs/:id/save", authenticateUser, async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const job = await storage.getJob(jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      await storage.saveJob(req.user!.id, jobId);
      res.status(200).json({ message: "Job saved successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error saving job" });
    }
  });

  app.delete("/api/jobs/:id/save", authenticateUser, async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      await storage.unsaveJob(req.user!.id, jobId);
      res.status(200).json({ message: "Job removed from saved jobs" });
    } catch (error) {
      res.status(500).json({ message: "Error removing saved job" });
    }
  });

  app.post("/api/jobs/:id/apply", authenticateUser, async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const job = await storage.getJob(jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      // Check if already applied
      const existingApplication = await storage.getApplicationByUserAndJob(req.user!.id, jobId);
      if (existingApplication) {
        return res.status(400).json({ message: "You have already applied for this job" });
      }
      
      await storage.createApplication(req.user!.id, jobId);
      res.status(200).json({ message: "Application submitted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error applying for job" });
    }
  });

  // Saved jobs routes
  app.get("/api/saved-jobs", authenticateUser, async (req, res) => {
    try {
      const savedJobs = await storage.getSavedJobsWithDetails(req.user!.id);
      res.json(savedJobs);
    } catch (error) {
      res.status(500).json({ message: "Error fetching saved jobs" });
    }
  });

  // Applications routes
  app.get("/api/applications", authenticateUser, async (req, res) => {
    try {
      const applications = await storage.getApplicationsWithDetails(req.user!.id);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: "Error fetching applications" });
    }
  });

  app.post("/api/applications/:id/withdraw", authenticateUser, async (req, res) => {
    try {
      const applicationId = parseInt(req.params.id);
      const application = await storage.getApplication(applicationId);
      
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      if (application.userId !== req.user!.id) {
        return res.status(403).json({ message: "Not authorized to withdraw this application" });
      }
      
      await storage.withdrawApplication(applicationId);
      res.status(200).json({ message: "Application withdrawn successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error withdrawing application" });
    }
  });

  // Initialize database with mock data if empty
  const initializeDatabase = async () => {
    const jobsCount = await storage.countJobs();
    if (jobsCount === 0) {
      for (const job of mockJobs) {
        await storage.createJob(job);
      }
    }
  };
  
  // Initialize the database
  await initializeDatabase();

  const httpServer = createServer(app);
  return httpServer;
}
