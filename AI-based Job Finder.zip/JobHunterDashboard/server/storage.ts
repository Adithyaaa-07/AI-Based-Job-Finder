import { 
  users, 
  type User, 
  type InsertUser, 
  jobs, 
  type Job, 
  type InsertJob, 
  savedJobs, 
  type SavedJob, 
  applications, 
  type Application 
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User>;
  
  // Job methods
  getJob(id: number): Promise<Job | undefined>;
  getJobs(filters: any): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  countJobs(): Promise<number>;
  countMatchedJobsForUser(userId: number): Promise<number>;
  
  // Saved jobs methods
  saveJob(userId: number, jobId: number): Promise<SavedJob>;
  unsaveJob(userId: number, jobId: number): Promise<void>;
  getSavedJobsByUser(userId: number): Promise<SavedJob[]>;
  getSavedJobsWithDetails(userId: number): Promise<(SavedJob & { job?: Job })[]>;
  countSavedJobsByUser(userId: number): Promise<number>;
  
  // Applications methods
  getApplication(id: number): Promise<Application | undefined>;
  getApplicationByUserAndJob(userId: number, jobId: number): Promise<Application | undefined>;
  createApplication(userId: number, jobId: number): Promise<Application>;
  withdrawApplication(id: number): Promise<void>;
  getApplicationsByUser(userId: number): Promise<Application[]>;
  getApplicationsWithDetails(userId: number): Promise<(Application & { job?: Job })[]>;
  countApplicationsByUser(userId: number): Promise<number>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private jobsData: Map<number, Job>;
  private savedJobsData: Map<number, SavedJob>;
  private applicationsData: Map<number, Application>;
  private currentUserId: number;
  private currentJobId: number;
  private currentSavedJobId: number;
  private currentApplicationId: number;

  constructor() {
    this.users = new Map();
    this.jobsData = new Map();
    this.savedJobsData = new Map();
    this.applicationsData = new Map();
    this.currentUserId = 1;
    this.currentJobId = 1;
    this.currentSavedJobId = 1;
    this.currentApplicationId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: now
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error("User not found");
    }

    // Don't allow updating id or createdAt
    const { id: _, createdAt: __, ...updateFields } = userData;
    const updatedUser = { ...user, ...updateFields };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Job methods
  async getJob(id: number): Promise<Job | undefined> {
    return this.jobsData.get(id);
  }

  async getJobs(filters: any): Promise<Job[]> {
    let jobs = Array.from(this.jobsData.values());
    
    // Apply filters if provided
    if (filters) {
      if (filters.location) {
        jobs = jobs.filter(job => 
          job.location.toLowerCase().includes(filters.location.toLowerCase())
        );
      }
      
      if (filters.jobType && Array.isArray(filters.jobType) && filters.jobType.length > 0) {
        jobs = jobs.filter(job => filters.jobType.includes(job.jobType));
      }
      
      if (filters.locationType && Array.isArray(filters.locationType) && filters.locationType.length > 0) {
        jobs = jobs.filter(job => filters.locationType.includes(job.locationType));
      }
      
      if (filters.experienceLevel && Array.isArray(filters.experienceLevel) && filters.experienceLevel.length > 0) {
        jobs = jobs.filter(job => filters.experienceLevel.includes(job.experienceLevel));
      }
      
      if (filters.salaryMin) {
        jobs = jobs.filter(job => 
          job.salaryMin ? job.salaryMin >= Number(filters.salaryMin) : true
        );
      }
      
      if (filters.salaryMax) {
        jobs = jobs.filter(job => 
          job.salaryMax ? job.salaryMax <= Number(filters.salaryMax) : true
        );
      }
      
      if (filters.skills && Array.isArray(filters.skills) && filters.skills.length > 0) {
        jobs = jobs.filter(job => 
          filters.skills.some((skill: string) => job.skills.includes(skill))
        );
      }
      
      if (filters.postedWithin) {
        const now = new Date();
        let since = new Date();
        
        switch (filters.postedWithin) {
          case 'day':
            since.setDate(now.getDate() - 1);
            break;
          case 'week':
            since.setDate(now.getDate() - 7);
            break;
          case 'month':
            since.setMonth(now.getMonth() - 1);
            break;
          default:
            // No filter for 'all'
            break;
        }
        
        if (filters.postedWithin !== 'all') {
          jobs = jobs.filter(job => new Date(job.postedDate) >= since);
        }
      }
    }
    
    return jobs;
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = this.currentJobId++;
    const now = new Date();
    const job: Job = {
      ...insertJob,
      id,
      postedDate: now
    };
    this.jobsData.set(id, job);
    return job;
  }

  async countJobs(): Promise<number> {
    return this.jobsData.size;
  }

  async countMatchedJobsForUser(userId: number): Promise<number> {
    const user = await this.getUser(userId);
    if (!user || !user.skills || user.skills.length === 0) {
      return 0;
    }
    
    const jobs = Array.from(this.jobsData.values());
    const userSkills = user.skills as string[];
    const matchedJobs = jobs.filter(job => {
      const matchingSkills = job.skills.filter(skill => userSkills.includes(skill));
      const matchPercentage = (matchingSkills.length / job.skills.length) * 100;
      return matchPercentage >= 65; // Consider a job matched if >= 65% match
    });
    
    return matchedJobs.length;
  }

  // Saved jobs methods
  async saveJob(userId: number, jobId: number): Promise<SavedJob> {
    // Check if already saved
    const existing = Array.from(this.savedJobsData.values()).find(
      savedJob => savedJob.userId === userId && savedJob.jobId === jobId
    );
    
    if (existing) {
      return existing;
    }
    
    const id = this.currentSavedJobId++;
    const savedJob: SavedJob = {
      id,
      userId,
      jobId,
      savedAt: new Date()
    };
    
    this.savedJobsData.set(id, savedJob);
    return savedJob;
  }

  async unsaveJob(userId: number, jobId: number): Promise<void> {
    const savedJobEntry = Array.from(this.savedJobsData.entries()).find(
      ([_, savedJob]) => savedJob.userId === userId && savedJob.jobId === jobId
    );
    
    if (savedJobEntry) {
      this.savedJobsData.delete(savedJobEntry[0]);
    }
  }

  async getSavedJobsByUser(userId: number): Promise<SavedJob[]> {
    return Array.from(this.savedJobsData.values()).filter(
      savedJob => savedJob.userId === userId
    );
  }

  async getSavedJobsWithDetails(userId: number): Promise<(SavedJob & { job?: Job })[]> {
    const savedJobs = await this.getSavedJobsByUser(userId);
    
    return savedJobs.map(savedJob => {
      const job = this.jobsData.get(savedJob.jobId);
      return {
        ...savedJob,
        job
      };
    });
  }

  async countSavedJobsByUser(userId: number): Promise<number> {
    const savedJobs = await this.getSavedJobsByUser(userId);
    return savedJobs.length;
  }

  // Applications methods
  async getApplication(id: number): Promise<Application | undefined> {
    return this.applicationsData.get(id);
  }

  async getApplicationByUserAndJob(userId: number, jobId: number): Promise<Application | undefined> {
    return Array.from(this.applicationsData.values()).find(
      application => application.userId === userId && application.jobId === jobId
    );
  }

  async createApplication(userId: number, jobId: number): Promise<Application> {
    const id = this.currentApplicationId++;
    const application: Application = {
      id,
      userId,
      jobId,
      status: 'Applied',
      appliedAt: new Date()
    };
    
    this.applicationsData.set(id, application);
    return application;
  }

  async withdrawApplication(id: number): Promise<void> {
    const application = await this.getApplication(id);
    if (application) {
      // Update status to withdrawn instead of deleting
      const updatedApplication = { ...application, status: 'Withdrawn' as any };
      this.applicationsData.set(id, updatedApplication);
    }
  }

  async getApplicationsByUser(userId: number): Promise<Application[]> {
    return Array.from(this.applicationsData.values()).filter(
      application => application.userId === userId
    );
  }

  async getApplicationsWithDetails(userId: number): Promise<(Application & { job?: Job })[]> {
    const applications = await this.getApplicationsByUser(userId);
    
    return applications.map(application => {
      const job = this.jobsData.get(application.jobId);
      return {
        ...application,
        job
      };
    });
  }

  async countApplicationsByUser(userId: number): Promise<number> {
    const applications = await this.getApplicationsByUser(userId);
    return applications.length;
  }
}

export const storage = new MemStorage();
