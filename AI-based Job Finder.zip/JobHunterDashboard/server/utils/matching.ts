import { Job } from "@shared/schema";

/**
 * Calculate match percentage between job skills and user skills
 * @param jobSkills Array of skills required for the job
 * @param userSkills Array of user's skills
 * @returns Match percentage (0-100)
 */
export function calculateMatchPercentage(jobSkills: string[], userSkills: string[]): number {
  if (jobSkills.length === 0 || userSkills.length === 0) {
    return 0;
  }

  // Count matching skills
  const matchingSkills = jobSkills.filter(skill => 
    userSkills.includes(skill)
  ).length;

  // Calculate percentage
  const matchPercentage = Math.round((matchingSkills / jobSkills.length) * 100);
  
  return matchPercentage;
}

/**
 * Add match percentage to jobs based on user skills
 * @param jobs Array of jobs
 * @param userSkills Array of user's skills
 * @returns Array of jobs with match percentage
 */
export function matchJobs(jobs: Job[], userSkills: string[]): Job[] {
  return jobs.map(job => {
    const matchPercentage = calculateMatchPercentage(job.skills, userSkills);
    
    return {
      ...job,
      matchPercentage
    };
  });
}
