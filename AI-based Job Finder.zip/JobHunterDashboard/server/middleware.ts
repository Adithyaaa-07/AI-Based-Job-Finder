import { Request, Response, NextFunction } from "express";
import bcrypt from "bcrypt";

// Add user property to Request type
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        username: string;
      };
    }
  }
}

// Hash a password
export async function createHash(password: string): Promise<string> {
  const saltRounds = 10;
  return bcrypt.hash(password, saltRounds);
}

// Compare password with hash
export async function compareHash(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// Middleware to check if user is authenticated
export function authenticateUser(req: Request, res: Response, next: NextFunction) {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ message: "Authentication required" });
  }

  // Add user to request object
  req.user = {
    id: req.session.userId,
    username: "", // This would typically come from the session or be looked up
  };

  next();
}

// Middleware to handle errors
export function errorHandler(err: Error, req: Request, res: Response, next: NextFunction) {
  console.error("Error:", err);
  res.status(500).json({ message: "An unexpected error occurred" });
}
